/** @type {import('tailwindcss').Config} */

export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        "extended-green": "#E0F2F1",
        "custom-rgba": "rgba(240, 253, 244, 1)",
        "navbar-text": "rgba(74, 222, 128, 1)",
        "table-text": "rgba(55, 65, 81, 1)",
        "color-text": "rgba(107, 114, 128, 1)",
        "green-text":
          "linear-gradient(rgba(104, 178, 160, 1), rgba(74, 222, 128, 1))",
      },
      fontFamily: {
        "noto-sans-lao": ["Noto Sans Lao", "sans-serif"],
      },
      backgroundImage: {
        "full-color":
          "linear-gradient(rgba(104, 178, 160, 1), rgba(74, 222, 128, 1))",
        "click-button":
          "linear-gradient(70deg, rgba(255, 255, 255, 1), rgba(255, 255, 255, 0))",
      },
      backgroundColor: {
        "table-color": "rgba(226, 232, 240, 1)",
        "button-search": "rgba(52, 211, 153, 1)",
        file: "rgba(217, 217, 217, 1)",
        "kind-product": "rgba(220, 252, 231, 1)",
        "button-delete": "rgba(248, 113, 113, 1)",
      },
      boxShadow: {
        left: "4px 4px 6px 0px rgba(232, 232, 232, 1);",
      },
    },
  },
  plugins: [],
};
