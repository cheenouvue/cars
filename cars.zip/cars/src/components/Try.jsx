// src/components/ImageInputBox.jsx
import React, { useState } from 'react';

const ImageInputBox = () => {
  const [preview, setPreview] = useState(null);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="relative">
      <input
        id="fileInput"
        type="file"
        accept="image/*"
        onChange={handleImageChange}
        className="hidden"
      />
      <label
        htmlFor="fileInput"
        className="w-[166px] h-[122px] bg-file rounded-[6px] cursor-pointer flex justify-center items-center overflow-hidden"
      >
        {preview ? (
          <img src={preview} alt="Preview" className="object-cover w-full h-full" />
        ) : (
          <span className="text-transparent">Choose file</span>
        )}
      </label>
    </div>
  );
};

export default ImageInputBox;
