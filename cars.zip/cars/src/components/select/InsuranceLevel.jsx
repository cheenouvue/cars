import React, { useState } from "react";
import Imgsavelife from "../../assets/images/savelife.jpg";
import Imgapa from "../../assets/images/APA.png";
import Imgsokxay from "../../assets/images/sokxay.png";
import Imgallianz from "../../assets/images/Allianz.jpg";
import { CiCircleChevDown } from "react-icons/ci";

const InsuranceLevel = () => {
  const [selectedOption, setSelectedOption] = useState(null);
  const [isOpen, setIsOpen] = useState(false); // State to manage dropdown visibility

  const options = [
    { value: "option1", label: "ປະກັນໄພຊັ້ນ 1" },
    { value: "option2", label: "ປະກັນໄພຮອບດ້ານ"},
    { value: "option3", label: "ປະກັນໄພບຸກຄົນທີ່ 3"},
  ];

  const toggleDropdown = () => setIsOpen(!isOpen);

  const handleOptionClick = (option) => {
    setSelectedOption(option);
    setIsOpen(false); // Close the dropdown after selection
  };

  return (
    <div className="relative w-[400px] font-noto-sans-lao">
      <div
        className="h-[60px] border-2 border-green-500 rounded-[26px] cursor-pointer flex items-center px-4 justify-between"
        onClick={toggleDropdown}
      >
        <div className="flex">
          {selectedOption ? (
            <>
              <p className="ml-7 mt-1">{selectedOption.label}</p>
            </>
          ) : (
            <p className="ml-3 text-gray-500">ເລືອກປະກັນໄພ</p>
          )}
        </div>
        <CiCircleChevDown className="w-[25px] h-[25px] text-green-500" />
      </div>
      {isOpen && ( // Conditionally render the options
        <ul className="absolute left-0 w-full border border-gray-300 rounded-[26px] bg-white mt-6 z-10">
          {options.map((option) => (
            <li
              key={option.value}
              className="flex items-center p-2 hover:bg-green-300 cursor-pointer border-2 w-[324px] h-[52px] rounded-[26px] mx-[10px] my-[20px] ml-[30px]"
              onClick={() => handleOptionClick(option)}
            >
              <>
                <p className="ml-3 ml-7">{option.label}</p>
              </>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default InsuranceLevel;
