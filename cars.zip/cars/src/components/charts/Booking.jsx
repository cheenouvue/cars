import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";

function Booking() {
  const chartRef = useRef(null);

  useEffect(() => {
    const chartDom = chartRef.current;
    const myChart = echarts.init(chartDom);

    const option = {
      legend: {
        bottom: "0",
        left: "center",
        textStyle: {
          fontFamily: 'Noto Sans Lao',
        },
      },
      series: [
        {
          name: "Access From",
          type: "pie",
          radius: ["60%", "30%"],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: "#fff",
            borderWidth: 2,
          },
          label: {
            show: true,
            position: "center",
            fontSize: 20,
            fontFamily: "Noto Sans Lao",
          },
          emphasis: {
            label: {
              show: true,
              fontSize: 40,
              fontWeight: "bold",
            },
          },
          labelLine: {
            show: false,
          },
          data: [
            { value: 10, name: "ລົດໃຫຍ່ໄຟຟ້າ" },
            { value: 15, name: "ລົດຈັກໄຟຟ້າ" },
            { value: 20, name: "ລົດໃຫຍ່" },
            { value: 55, name: "ລົດຈັກ" },
          ],
        },
      ],
    };

    myChart.setOption(option);

    const handleResize = () => {
      myChart.resize();
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      myChart.dispose();
    };
  }, []); // Add empty dependency array to run effect only once

  return <div ref={chartRef} style={{ width: "338px", height: "370px"}} />;
}

export default Booking;