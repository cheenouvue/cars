import { color } from "chart.js/helpers";
import * as echarts from "echarts";
import React, { useEffect, useRef } from "react";
import { TbBackground } from "react-icons/tb";

function AddDataProduct() {
  const chartRef = useRef(null);
  useEffect(() => {
    const chartDom = chartRef.current;
    const myChart = echarts.init(chartDom);

    const option = {
      xAxis: {
        axisLine: { show: false },
        axisLabel: { show: false },
        splitLine: { show: false },
        axisTick: { show: false },
      },
      yAxis: {
        type: "value",
        axisTick: { show: false },
          min: 0,
          max: 50,
          interval: 10,
        axisLine: { show: false },
        axisLabel: { show: false },
        splitLine: { show: false },
        axisTick: { show: false },
      },
      series: [
        {
          type: "line",
          showSymbol: false,
          lineStyle: {
            color: "lightGrey"
          },
          data: [
            [0, 20],
            [1, 20],
          ],
        },
      ],
    };

    option && myChart.setOption(option);
  }, []);
  return <div id="main" ref={chartRef} className="w-[140px] h-[50px]" />;
}

export default AddDataProduct;
