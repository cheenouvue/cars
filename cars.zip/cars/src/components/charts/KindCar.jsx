import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";
import "@fontsource/noto-sans-lao";

const KindCar = () => {
  const chartRef = useRef(null);

  useEffect(() => {
    const chartDom = chartRef.current;
    const myChart = echarts.init(chartDom);

    const option = {
      color: ['rgba(255, 251, 235, 1)', 'rgba(254, 240, 138, 1)'],
      series: [
        {
          name: "Access From",
          type: "pie",
          radius: ["65%", "85%"],
          avoidLabelOverlap: false,
          label: {
            show: true,
            position: "center",
            fontFamily: "Noto Sans Lao",
          },
          emphasis: {
            label: {
              show: true,
              fontSize: 14,
              fontWeight: "bold",
            },
          },
          labelLine: {
            show: false,
          },
          itemStyle: {
            borderColor: 'rgba(254, 242, 242, 1)', // Border color
            borderWidth: 1, // Border width
          },
          data: [
            { value: 40, name: "1\nປະເພດ"},
            { value: 100, name: "4\nປະເພດ" },
            
          ],
        },
      ],
    };

    myChart.setOption(option);

    const handleResize = () => {
      myChart.resize();
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      myChart.dispose();
    };
  }, []);

  return <div ref={chartRef} className="w-[100px] h-[100px] justify-end font-noto-sans-lao" />;
};

export default KindCar;
