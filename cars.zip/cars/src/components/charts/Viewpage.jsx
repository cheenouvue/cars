import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";
import "@fontsource/noto-sans-lao";
import { color } from "chart.js/helpers";

function Viewpage() {
  const chartRef = useRef(null);

  useEffect(() => {
    const chartDom = chartRef.current;
    const myChart = echarts.init(chartDom);

    const option = {
      color: ["#80FFA5"],
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "cross",
          label: {
            backgroundColor: "#6a7985",
          },
        },
      },
      grid: {
        left: "5%",
        right: "4%",
        bottom: "3%",
        containLabel: true,
      },
      xAxis: [
        {
          type: "category",
          boundaryGap: false,
          axisTick: { show: false },
          data: [
            "0",
            "1/5",
            "2/5",
            "3/5",
            "4/5",
            "5/5",
            "6/5",
            "7/5",
            "8/5",
            "9/5",
            "10/5",
          ],
          axisLabel: {
            formatter: function (category) {
              return category === "0" ? "" : category;
            },
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: "rgba(156, 163, 175, 1)",
            },
          },
        },
      ],
      yAxis: [
        {
          type: "value",
          boundaryGap: false,
          axisTick: { show: false },
          min: 0,
          max: 50,
          interval: 10,
          axisLabel: {
            formatter: function (value) {
              return value === 0 ? "" : value;
            },
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: "rgba(156, 163, 175, 1)",
            },
          },
          splitLine: {
            show: true,
            lineStyle: {
              type: "dashed",
              color: "rgba(226, 232, 240, 1)",
              width: 1,
            },
          },
        },
      ],
      series: [
        {
          type: "line",
          stack: "Total",
          smooth: true,
          lineStyle: {
            width: 0,
          },
          showSymbol: false,
          areaStyle: {
            opacity: 0.8,
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "rgba(104, 178, 160, 0.7)",
              },
              {
                offset: 0,
                color: "rgba(74, 222, 128, 0.7)",
              },
            ]),
          },
          emphasis: {
            focus: "series",
          },
          data: [19, 32, 8, 39, 28, 50, 18, 31.5, 8.5, 50, 8],
        },
      ],
    };

    myChart.setOption(option);

    const handleResize = () => {
      myChart.resize();
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      myChart.dispose();
    };
  }, []);

  return <div id="main" ref={chartRef} className="w-[800px] h-[370px]" />;
}

export default Viewpage;
