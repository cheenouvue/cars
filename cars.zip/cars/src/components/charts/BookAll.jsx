import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";
import "@fontsource/noto-sans-lao";

const KookAll = () => {
  const chartRef = useRef(null);

  useEffect(() => {
    const chartDom = chartRef.current;
    const myChart = echarts.init(chartDom);

    const option = {
      color: ['rgba(254, 242, 242, 1)', 'rgba(252, 165, 165, 1)'],
      series: [
        {
          name: "Access From",
          type: "pie",
          radius: ["65%", "85%"],
          avoidLabelOverlap: false,
          label: {
            show: true,
            position: "center",
            fontFamily: "Noto Sans Lao",
          },
          emphasis: {
            label: {
              show: true,
              fontSize: 14,
              fontWeight: "bold",
            },
          },
          labelLine: {
            show: false,
          },
          itemStyle: {
            borderColor: 'rgba(254, 242, 242, 1)', // Border color
            borderWidth: 1, // Border width
          },
          data: [
            { value: 40, name: "40\nລາຍການ"},
            { value: 100, name: "100\nລາຍການ" },
            
          ],
        },
      ],
    };

    myChart.setOption(option);

    const handleResize = () => {
      myChart.resize();
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      myChart.dispose();
    };
  }, []);

  return <div ref={chartRef} className="w-[100px] h-[100px] justify-end font-noto-sans-lao" />;
};

export default KookAll;
