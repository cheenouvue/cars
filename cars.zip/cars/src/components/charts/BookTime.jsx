import { color } from "chart.js/helpers";
import * as echarts from "echarts";
import React, { useEffect, useRef } from "react";

function BookTime() {
  const chartRef = useRef(null);
  useEffect(() => {
    const chartDom = chartRef.current;
    const myChart = echarts.init(chartDom);

    const option = {
      xAxis: {
        axisLine: { show: false },
        axisLabel: { show: false },
        splitLine: { show: false },
        axisTick: { show: false },
      },
      yAxis: {
        axisLine: { show: false },
        axisLabel: { show: false },
        splitLine: { show: false },
        axisTick: { show: false },
      },
      series: [
        {
          data: [
            [0, 20],
            [5, 20],
            [10, 20],
            [15, 20],
            [20, 20],
          ],
          type: "line",
        },
      ],
    };

    option && myChart.setOption(option);
  }, []);
  return <div id="main" ref={chartRef} className="w-[146px] h-[100px]" />;
}

export default BookTime;
