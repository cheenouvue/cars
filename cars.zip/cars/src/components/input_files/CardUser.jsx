import React, { useState } from "react";

function CardUser() {
  const [card, setcard] = useState(null);

  const ImageCards = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setcard(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  return (
    <div>
      <input
        id="carduser"
        type="file"
        accept="image/*"
        onChange={ImageCards}
        className="hidden"
      />
      <label
        htmlFor="carduser"
        className="bg-file rounded-[4px] cursor-pointer flex justify-center items-center overflow-hidden w-[120px] h-[100px]"
      >
        {card ? (
          <img src={card} alt="card" className="object-cover w-full h-full" />
        ) : (
          <span className="text-transparent">Choose file</span>
        )}
      </label>
    </div>
  );
}

export default CardUser;
