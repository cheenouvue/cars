import React, { useState } from "react";

function CardProduct() {
  const [cardproduct, setcardproduct] = useState(null);
  const [cardproduct1, setcardproduct1] = useState(null);
  const [cardproduct2, setcardproduct2] = useState(null);
  const [cardproduct3, setcardproduct3] = useState(null);

  const ImageCredProduct = (e) => {
    const file = e.target.files[0];

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setcardproduct(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const ImageCredProduct1 = (e) => {
    const file = e.target.files[0];

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setcardproduct1(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const ImageCredProduct2 = (e) => {
    const file = e.target.files[0];

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setcardproduct2(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const ImageCredProduct3 = (e) => {
    const file = e.target.files[0];

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setcardproduct3(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  return (
    <div className="flex space-x-[20px]">
      <div className="ml-[20px]">
        <input
          id="cardproduct"
          type="file"
          accept="image/*"
          onChange={ImageCredProduct}
          className="hidden"
        />
        <label
          htmlFor="cardproduct"
          className="bg-file rounded-[4px] cursor-pointer flex justify-center items-center overflow-hidden w-[120px] h-[100px]"
        >
          {cardproduct ? (
            <img
              src={cardproduct}
              alt="cardproduct"
              className="object-cover w-full h-full"
            />
          ) : (
            <span className="text-transparent">Choose file</span>
          )}
        </label>
      </div>
      <div>
        <input
          id="cardproduct1"
          type="file"
          accept="image/*"
          onChange={ImageCredProduct1}
          className="hidden"
        />
        <label
          htmlFor="cardproduct1"
          className="bg-file rounded-[4px] cursor-pointer flex justify-center items-center overflow-hidden w-[120px] h-[100px]"
        >
          {cardproduct1 ? (
            <img
              src={cardproduct1}
              alt="cardproduct1"
              className="object-cover w-full h-full"
            />
          ) : (
            <span className="text-transparent">Choose file</span>
          )}
        </label>
      </div>
      <div>
        <input
          id="cardproduct2"
          type="file"
          accept="image/*"
          onChange={ImageCredProduct2}
          className="hidden"
        />
        <label
          htmlFor="cardproduct2"
          className="bg-file rounded-[4px] cursor-pointer flex justify-center items-center overflow-hidden w-[120px] h-[100px]"
        >
          {cardproduct2 ? (
            <img
              src={cardproduct2}
              alt="cardproduct2"
              className="object-cover w-full h-full"
            />
          ) : (
            <span className="text-transparent">Choose file</span>
          )}
        </label>
      </div>
      <div>
        <input
          id="cardproduct3"
          type="file"
          accept="image/*"
          onChange={ImageCredProduct3}
          className="hidden"
        />
        <label
          htmlFor="cardproduct3"
          className="bg-file rounded-[4px] cursor-pointer flex justify-center items-center overflow-hidden w-[120px] h-[100px]"
        >
          {cardproduct3 ? (
            <img
              src={cardproduct3}
              alt="cardproduct3"
              className="object-cover w-full h-full"
            />
          ) : (
            <span className="text-transparent">Choose file</span>
          )}
        </label>
      </div>
    </div>
  );
}

export default CardProduct;
