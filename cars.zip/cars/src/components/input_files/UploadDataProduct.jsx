import React, { useState } from "react";
import { TbCameraPlus } from "react-icons/tb";

function UploadDataProduct() {
  const [datauser, setdatauser] = useState(null);

  const Imagedatausers = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setdatauser(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  return (
    <div>
      <input
        id="datauser"
        type="file"
        accept="image/*"
        onChange={Imagedatausers}
        className="hidden"
      />
      <label
        htmlFor="datauser"
        className="bg-slate-200 rounded-[4px] cursor-pointer flex justify-center items-center overflow-hidden w-[120px] h-[100px]"
      >
        {datauser ? (
          <img
            src={datauser}
            alt="datauser"
            className="object-cover w-full h-full"
          />
        ) : (
          <span className="text-transparent border-2 border-dashed border-slate-300 py-[10px] px-[20px] rounded-[4px]">
            <TbCameraPlus className="w-[48px] h-[48px] text-slate-300" />
          </span>
        )}
      </label>
    </div>
  );
}

export default UploadDataProduct;
