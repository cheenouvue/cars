import React, { useState } from "react";
import { TbCameraPlus } from "react-icons/tb";

function CardUser() {
  const [carduser, setcarduser] = useState(null);

  const ImageCardusers = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setcarduser(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  return (
    <div>
      <input
        id="carduser"
        type="file"
        accept="image/*"
        onChange={ImageCardusers}
        className="hidden"
      />
      <label
        htmlFor="carduser"
        className="bg-slate-200 rounded-[4px] cursor-pointer flex justify-center items-center overflow-hidden w-[120px] h-[100px]"
      >
        {carduser ? (
          <img
            src={carduser}
            alt="carduser"
            className="object-cover w-full h-full"
          />
        ) : (
          <span className="text-transparent border-2 border-dashed border-slate-300 py-[10px] px-[20px] rounded-[4px]">
            <TbCameraPlus className="w-[48px] h-[48px] text-slate-300" />
          </span>
        )}
      </label>
    </div>
  );
}

export default CardUser;
