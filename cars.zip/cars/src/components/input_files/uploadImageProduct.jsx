import React, { useState } from "react";
import { IoIosCloudUpload } from "react-icons/io";
import { LuImagePlus } from "react-icons/lu";

function uploadImageProduct() {
  const [datauser, setdatauser] = useState(null);

  const Imagedatausers = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setdatauser(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  return (
    <div className="font-noto-sans-lao mt-[30px]">
        <div className="flex justify-center items-center w-[896px] h-[326px] rounded-[6px] bg-slate-200">
          {datauser ? (
            <img
              src={datauser}
              alt="datauser"
              className="object-cover w-[896px] h-[326px]"
            />
          ) : (
            <span className="text-transparent border-2 border-dashed border-gray-300 rounded-[4px] w-[816px] h-[246px] flex justify-center items-center">
              <LuImagePlus className="w-[120px] h-[120px] text-gray-300" />
            </span>
          )}
        </div>
        <input
          id="datauser"
          type="file"
          accept="image/*"
          onChange={Imagedatausers}
          className="hidden"
        />
        <label
          htmlFor="datauser"
          className="w-[140px] h-[40px] mt-[20px] bg-green-200 rounded-[18px] flex justify-center items-center"
        >
          <IoIosCloudUpload className="w-[24px] h-[24px] text-white" />
          <p className="ml-3">ອັບໂຫລພາບ</p>
        </label>
    </div>
  );
}

export default uploadImageProduct;