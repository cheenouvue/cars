import React, { useState } from "react";

const InputProduct = () => {
  const [preview, setPreview] = useState(null);
  const [preview1, setPreview1] = useState(null);
  const [preview2, setPreview2] = useState(null);
  const [preview3, setPreview3] = useState(null);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageChange1 = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview1(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageChange2 = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview2(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageChange3 = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview3(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="relative flex">
      <div>
        <input
          id="headproduct"
          type="file"
          accept="image/*"
          onChange={handleImageChange}
          className="hidden"
        />
        <label
          htmlFor="headproduct"
          className="bg-file rounded-[6px] cursor-pointer flex justify-center items-center overflow-hidden w-[508px] h-[350px]"
        >
          {preview ? (
            <img
              src={preview}
              alt="Preview"
              className="object-cover w-full h-full"
            />
          ) : (
            <span className="text-transparent">Choose file</span>
          )}
        </label>
      </div>
      <div className="ml-[30px]">
        <div>
          <input
            id="sideproduct"
            type="file"
            accept="image/*"
            onChange={handleImageChange1}
            className="hidden"
          />
          <label
            htmlFor="sideproduct"
            className="bg-file rounded-[6px] cursor-pointer flex justify-center items-center overflow-hidden w-[454px] h-[160px]"
          >
            {preview1 ? (
              <img
                src={preview1}
                alt="Preview1"
                className="object-cover w-full h-full"
              />
            ) : (
              <span className="text-transparent">Choose file</span>
            )}
          </label>
        </div>
        <div className="flex my-[20px] space-x-[20px]">
          <div>
            <input
              id="footproduct"
              type="file"
              accept="image/*"
              onChange={handleImageChange2}
              className="hidden"
            />
            <label
              htmlFor="footproduct"
              className="bg-file rounded-[6px] cursor-pointer flex justify-center items-center overflow-hidden w-[218px] h-[170px]"
            >
              {preview2 ? (
                <img
                  src={preview2}
                  alt="Preview2"
                  className="object-cover w-full h-full"
                />
              ) : (
                <span className="text-transparent">Choose file</span>
              )}
            </label>
          </div>
          <div>
          <input
            id="otherproduct"
            type="file"
            accept="image/*"
            onChange={handleImageChange3}
            className="hidden"
          />
          <label
            htmlFor="otherproduct"
            className="bg-file rounded-[6px] cursor-pointer flex justify-center items-center overflow-hidden w-[218px] h-[170px]"
          >
            {preview3 ? (
              <img
                src={preview3}
                alt="Preview3"
                className="object-cover w-full h-full"
              />
            ) : (
              <span className="text-transparent">Choose file</span>
            )}
          </label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InputProduct;
