import React from 'react'
import { CiBellOn } from "react-icons/ci";
import ImgProfire from ".././assets/images/person.png";

function HeadBar() {
  return (
    <div className="py-3 flex justify-end space-x-4 bg-white rounded-[6px] ml-[20px] pl-[950px] px-[20px]">
        <div>
          <a href="#">
            <CiBellOn className="w-[35px] h-[35px]" />
          </a>
        </div>
        <div className="w-[40px] h-[40px]">
          <a href="#">
            <img
              src={ImgProfire}
              alt=""
              className="w-[35px] h-[38px] border-[1px] border-green-500 rounded-[30px] object-cover"
            />
          </a>
        </div>
        <div className="text-[10px]">
          Cheenouvue Negthong
          <br />
          Admin
        </div>
      </div>
  )
}

export default HeadBar