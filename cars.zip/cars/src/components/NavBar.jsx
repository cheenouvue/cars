import React from "react";
import { NavLink } from "react-router-dom";
import { FaUserCircle } from "react-icons/fa"; //icons
import { IoCarSportOutline } from "react-icons/io5";
import { FiUsers } from "react-icons/fi";
import { AiOutlineFileAdd, AiOutlineFileDone } from "react-icons/ai";
import { TbReportAnalytics } from "react-icons/tb";
import { LuUserCog } from "react-icons/lu";
import { VscGraph } from "react-icons/vsc";
import { IoMdLogOut } from "react-icons/io";
import { SlHome } from "react-icons/sl";
import HeadBar from "./HeadBar";
import "../style/NavBar.css";
import mirror from ".././assets/icons/mirror.svg";

function NavBar({ children }) {
  const linkClass = ({ isActive }) => {
    return isActive
      ? "icons bg-click-button text-navbar-text py-[10px] px-[30px]" //click
      : "icons my-[10px] py-[10px] px-[30px]"; //not click
  };

  return (
    <div className="px-[10px] py-[10px] bg-slate-100 min-h-screen h-full">
      <nav className="flex">
        <div className="sticky top-3 bg-full-color rounded-[8px] text-white font-noto-sans-lao w-[240px] h-[700px]">
          <div className="my-[25px] grid_icons w-[56px] h-[56px] text-gray-400">
            {/* <FaUserCircle className="w-[56px] h-[56px] ml-[30px]" /> */}
            {/* <img src={mirror} alt="" className=""/> */}
            <svg
                  className="h-[40px] w-[40px] text-gray-400"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  {/* แทรกโค้ด SVG ที่ได้จาก item.icon ที่นี่ */}
                  <path src="M12 2L2 12h3v8h14v-8h3L12 2z"/>
                  {/* <img src={cloudinaryResizeImage(item.icon, 80)} alt="icon"/> */}
                </svg>
            <div className="text-[20px] content-center">Cheenou</div>
          </div>
          <ul className="my-[60px]">
            <li>
              <NavLink to="/" className={linkClass}>
                <div className="flex space-x-[25px]">
                  <div>
                    <SlHome className="w-[24px] h-[24px]" />
                  </div>
                  <p className="text-[16px]">Dashboard</p>
                </div>
              </NavLink>
            </li>
            <li>
              <NavLink to="/user/page" className={linkClass}>
                <div className="flex space-x-[25px]">
                  <div>
                    <FiUsers className="w-[24px] h-[24px]" />
                  </div>
                  <div className="">
                    <p className="text-[16px] w-[100px]">ຜູ້ໃຊ້</p>
                  </div>
                </div>
              </NavLink>
            </li>
            <li>
              <NavLink to="/kindofcars" className={linkClass}>
                <IoCarSportOutline className="w-[24px] h-[24px]" />
                <div className="text-[16px]">ປະເພດລົດ</div>
              </NavLink>
            </li>
            <li>
              <NavLink to="/product" className={linkClass}>
                <AiOutlineFileAdd className="w-[24px] h-[24px]" />
                <div className="text-[16px]">ຈັດການການໂພສ</div>
              </NavLink>
            </li>
            <li>
              <NavLink to="/vv" className={linkClass}>
                <AiOutlineFileDone className="w-[24px] h-[24px]" />
                <div className="text-[16px]">ຈັດການການຈອງ</div>
              </NavLink>
            </li>
            <li>
              <NavLink to="/report" className={linkClass}>
                <TbReportAnalytics className="w-[24px] h-[24px]" />
                <div className="text-[16px]">ປະຫວັດການຈອງ</div>
              </NavLink>
            </li>
            <li>
              <NavLink to="/user-cog" className={linkClass}>
                <LuUserCog className="w-[24px] h-[24px]" />
                <div className="text-[16px]">ຜູ້ໃຊ້ລະບົບ</div>
              </NavLink>
            </li>
            <li>
              <NavLink to="/graph" className={linkClass}>
                <VscGraph className="w-[24px] h-[24px]" />
                <div className="text-[16px]">ລາຍງານ</div>
              </NavLink>
            </li>
            <li>
              <NavLink to="/ex" className={linkClass}>
                <IoMdLogOut className="w-[24px] h-[24px]" />
                <div className="text-[16px]">ອອກຈາກລະບົບ</div>
              </NavLink>
            </li>
          </ul>
        </div>
        <div>
          <div>
            <HeadBar />
          </div>
          <div>{children}</div>
        </div>
      </nav>
    </div>
  );
}

export default NavBar;
