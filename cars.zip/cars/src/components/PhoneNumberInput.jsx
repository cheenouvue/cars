// src/components/PhoneNumberInput.jsx
import React, { useState } from 'react';

const PhoneNumberInput = () => {
  const [phoneNumber, setPhoneNumber] = useState('+856');

  const handleChange = (e) => {
    // Get the input value
    let input = e.target.value;

    // Ensure the input starts with the default country code
    // if (!input.startsWith('+856 ')) {
    //   input = '+856 ';
    // }

    // Update the state
    setPhoneNumber(input);
  };

  return (
    <div className="flex items-center">
      <input
        type="tel"
        value={phoneNumber}
        // onChange={handleChange}
        className="border-[2px] w-[80px] h-[44px] rounded-tl-[20px] rounded-bl-[20px] pl-[20px] mt-[10px] text-color-text"
        // placeholder="Enter phone number"
        maxLength="16"
      />
      <input
        type="tel"
        // value={phoneNumber}
        onChange={handleChange}
        className="border-[2px] w-[240px] h-[44px] ml-[2px] rounded-tr-[20px] rounded-br-[20px] pl-[20px] mt-[10px] text-color-text"
        // placeholder="Enter phone number"
        maxLength="11"
      />
    </div>
  );
};

export default PhoneNumberInput;
