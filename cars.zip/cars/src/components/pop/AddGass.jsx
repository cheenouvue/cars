import React from "react";
import { BiX } from "react-icons/bi";
import { BsUpload } from "react-icons/bs";

function AddGass({ isOpen, onClose }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 flex items-center justify-center">
      <div className="fixed inset-0 bg-black opacity-30" onClick={onClose}></div>
      <div className="bg-white rounded-[8px] shadow-lg p-6 relative z-10 w-[560px] h-[374px] font-noto-sans-lao">
        <div className="flex justify-between pl-[30px] pr-[10px] pt-[15px]">
          <p className="text-[20px] text-green-400">ເພິ່ມປະເພດເຊື້ອເພີງ</p>
          <BiX className="w-[24px] h-[24px] text-slate-400 cursor-pointer" onClick={onClose} />
        </div>

        <div className="flex justify-center mt-[30px]">
          <input
            type="text"
            className="w-[448px] h-[44px] border-[1px] border-green-500 rounded-[20px] pl-[60px] focus:outline-none focus:ring-[2px] focus:ring-green-500"
            placeholder="ກະລະນາປ້ອນຊື່...."
          />
        </div>
        <div className="ml-[30px] mt-[10px]">
          <input type="file" name="file" id="file" className="hidden" />
          <label
            htmlFor="file"
            className="w-[164px] h-[44px] rounded-[20px] border-[2px] flex items-center justify-between px-[20px] text-slate-700 cursor-pointer"
          >
            <BsUpload className="w-[24px] h-[24px]" />
            <p>ອັບໂຫລດຮູບ</p>
          </label>
        </div>
        <div className="flex justify-center mt-[110px] space-x-[20px]">
          <button
            className="w-[100px] h-[40px] bg-white hover:bg-white-600 rounded-[20px] border-[2px] focus:ring-[2px] focus:ring-slate-100 hover:bg-slate-50 text-[16px]"
            onClick={onClose}
          >
            ຍົກເລີກ
          </button>
          <button
            className="w-[100px] h-[40px] text-white bg-button-search rounded-[20px] focus:ring-[2px] focus:ring-green-600 hover:bg-green-400 text-[16px]"
            onClick={onClose}
          >
            ບັນທຶກ
          </button>
        </div>
      </div>
    </div>
  );
}

export default AddGass;
