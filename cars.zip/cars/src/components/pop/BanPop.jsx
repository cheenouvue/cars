import React from "react";
import { MdOutlineReport } from "react-icons/md";

function BanPop({ isOpen, onClose }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50">
      <div className="fixed inset-0 bg-black opacity-5" onClick={onClose}></div>
      <div className="bg-white rounded-[8px] shadow-lg p-6 relative z-10 w-[400px] h-[270px]">
        <p className="text-[20px] text-center font-noto-sans-lao mt-[20px]">
          ທ່ານຕ້ອງການ ແບນ ລາຍການນນີ້ແມ່ນບໍ່ ?
        </p>
        <div className="flex justify-center mt-[20px]">
          <MdOutlineReport className="w-[60px] h-[60px] text-red-500" />
        </div>
        <div className="flex justify-center mt-[40px] space-x-[10px]">
          <button
            className="w-[100px] h-[40px] bg-white hover:bg-white-600 rounded-[20px] border-[2px] focus:ring-[2px] focus:ring-slate-100 hover:bg-slate-50 font-noto-sans-lao text-[16px]"
            onClick={onClose}
          >
            ຍົກເລີກ
          </button>
          <button
            className="w-[100px] h-[40px] bg-button-search rounded-[20px] focus:ring-[2px] focus:ring-green-600 hover:bg-green-400 font-noto-sans-lao text-[16px]"
            onClick={onClose}
          >
            ຕົກລົງ
          </button>
        </div>
      </div>
    </div>
  );
}

export default BanPop;
