import React, { useState } from "react";
import { CiCircleChevDown, CiCircleChevLeft } from "react-icons/ci";

const Select = ({ options, onChange, value, placeholder }) => {
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = () => setIsFocused(true);
  const handleBlur = () => setIsFocused(false);

  return (
    <div className="relative w-full">
      <div className="relative flex items-center w-full h-[44px]">
        <select
          value={value}
          onChange={onChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          className="w-[160px] h-[44px] px-8 bg-white border-[1px] border-green-500 text-green-500 rounded-[20px] appearance-none focus:outline-none focus:ring-2 focus:ring-green-500 cursor-pointer"
        >
          {!value && !isFocused && <option value="">{placeholder}</option>}
          {options.map((option, index) => (
            <option key={index} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <div className="absolute left-[115px] text-green-500 cursor-pointer">
          {isFocused ? (
            <CiCircleChevDown className=" w-[40px] h-[22px]" />
          ) : (
            <CiCircleChevLeft className=" w-[40px] h-[22px]" />
          )}
        </div>
      </div>
    </div>
  );
};

export default Select;
