import React from "react";
import NavBar from "../components/NavBar";
import { MdArrowBack } from "react-icons/md"; //icons
import { FaUser } from "react-icons/fa";
import { FaCar } from "react-icons/fa6";
import { IoIosCloudUpload } from "react-icons/io";
import AddDataProduct from "../components/charts/AddDataProduct";
import UploadCardUser from "../components/input_files/UploadCardUser";
import UploadDataProduct from "../components/input_files/UploadDataProduct";
import { NavLink } from "react-router-dom";
import Insurance from "../components/select/Insurance";
import InsuranceLevel from "../components/select/InsuranceLevel";

function AddProducts() {
  // const [selectedOption, setSelectedOption] = useState("");
  return (
    <NavBar>
      <div className="font-noto-sans-lao">
        <div className="flex space-x-[20px] items-center ml-[130px] my-[30px]">
          <NavLink to="/admin">
            <MdArrowBack className="w-[42px] h-[46px] text-green-400" />
          </NavLink>
          <p className="text-[24px]">ເພີ່ມຂໍ້ມູນລົດເຊົ່າ</p>
        </div>
        {/* container */}
        <div className="w-[1008px] h-[1650px] bg-white ml-[80px] rounded-[6px]">
          <div className="flex justify-center items-center py-[30px]">
            <div className="w-[40px] h-[40px] bg-green-400 rounded-[20px] flex justify-center items-center mt-[10px]">
              <FaUser className="w-[16px] h-[16px] text-white" />
            </div>
            <div className="fexl items-center">
              <AddDataProduct />
            </div>
            <div className="w-[40px] h-[40px] bg-slate-200 rounded-[20px] flex justify-center items-center mt-[10px]">
              <FaCar className="w-[16px] h-[16px] text-slate-400" />
            </div>
          </div>
          {/* container */}
          <div>
            <form action="" className="w-full ">
              <table className="w-[800px] h-full ml-[140px]">
                <tr className="mt-[30px]">
                  <td>
                    <label htmlFor="name" className="flex ml-5">
                      <p>ຊື່</p>
                      <p className="text-red-500 ml-1">*</p>
                    </label>
                  </td>
                  <td>
                    <label htmlFor="lastname" className="flex ml-5">
                      <p>ນາມສະກຸນ</p>
                      <p className="text-red-500 ml-1">*</p>
                    </label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <input
                      type="text"
                      name=""
                      id="name"
                      placeholder="ກະລຸນາປ້ອນຊື່"
                      className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      name=""
                      id="lastname"
                      placeholder="ກະລຸນາປ້ອນນາມສະກຸນ"
                      className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                    />
                  </td>
                </tr>
                <div className="mt-[20px]" />
                <tr>
                  <td>
                    <label htmlFor="phone" className="flex ml-5">
                      <p>ເບີໂທ</p>
                      <p className="text-red-500 ml-1">*</p>
                    </label>
                  </td>
                  <td>
                    <label htmlFor="vilage" className="ml-[20px]">
                      ບ້ານ
                    </label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="flex items-center">
                      <input
                        type="tel"
                        value="+ 856"
                        className="border-[2px] w-[80px] h-[44px] rounded-tl-[20px] rounded-bl-[20px] pl-[20px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                      />
                      <input
                        type="tel"
                        id="phone"
                        placeholder="ກະລຸນາປ້ອນເບີໂທ"
                        className="border-[2px] w-[240px] h-[44px] ml-[2px] rounded-tr-[20px] rounded-br-[20px] pl-[20px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                        maxLength="11"
                      />
                    </div>
                  </td>
                  <td>
                    <input
                      type="text"
                      name=""
                      id="vilage"
                      placeholder="ກະລຸນາປ້ອນບ້ານ"
                      className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text pr-[10px] focus:border-green-500 focus:outline-none"
                    />
                  </td>
                </tr>
                <div className="mt-[20px]" />
                <tr>
                  <td>
                    <label htmlFor="phone" className="ml-[20px]">
                      ເມືອງ
                    </label>
                  </td>
                  <td>
                    <label htmlFor="password" className="ml-[20px]">
                      ແຂວງ
                    </label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="flex items-center">
                      <input
                        type="text"
                        name=""
                        id="password"
                        placeholder="ກະລຸນາປ້ອນເມືອງ"
                        className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text pr-[10px] focus:border-green-500 focus:outline-none"
                      />
                    </div>
                  </td>
                  <td>
                    <input
                      type="text"
                      name=""
                      id="password"
                      placeholder="ກະລຸນາປ້ອນແຂວງ"
                      className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text pr-[10px] focus:border-green-500 focus:outline-none"
                    />
                  </td>
                </tr>
                <div className="mt-[20px]" />
                <tr>
                  <td>
                    <label htmlFor="number_card" className="flex ml-5">
                      <p>ເລກບັດປະຈຳໂຕ</p>
                      <p className="text-red-500 ml-1">*</p>
                    </label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <input
                      type="number"
                      name=""
                      id="number_card"
                      placeholder="ກະລຸນາປ້ອນເລກບັດປະຈຳໂຕ"
                      className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                    />
                  </td>
                </tr>
              </table>
              <div className="ml-[140px] mt-[25px]">
                <div className="flex ml-[20px]">
                  <IoIosCloudUpload className="w-[24px] h-[24px] text-slate-300" />
                  <p className="ml-3">ອັບໂຫລດຮູບບັດປະຈຳໂຕ</p>
                  <p className="ml-1 text-red-500">*</p>
                </div>
                <div className="w-[804px] h-[150px] border-2 rounded-[6px] mt-[15px] flex items-center pl-[20px]">
                  <UploadCardUser />
                </div>
              </div>
              <div className="ml-[140px] mt-[35px]">
                <div className="flex ml-[20px]">
                  <IoIosCloudUpload className="w-[24px] h-[24px] text-slate-300" />
                  <p className="ml-3">ອັບໂຫລດຮູບບັດປະຈຳໂຕ</p>
                  <p className="ml-1 text-red-500">*</p>
                </div>
                <div className="w-[804px] h-[150px] border-2 rounded-[6px] mt-[15px] flex items-center pl-[20px]">
                  <UploadDataProduct />
                </div>
              </div>
            </form>
          </div>
          <div className="ml-[140px] mt-[60px]">
            <p className="text-[24px]">ປະກັນໄພ</p>
            <div className="flex mt-[30px]">
              <div>
                <div className="flex ml-[15px]">
                  <p>ເລຶອກບໍລິສັດປະກັນໄພ</p>
                  <p className="ml-1 text-red-500">*</p>
                </div>
                <div className="mt-[10px]">
                  <Insurance />
                </div>
              </div>
              <div className="ml-[30px]">
                <div className="flex ml-[15px]">
                  <p>ເລືອກລະດັບປະກັນໄພ</p>
                  <p className="ml-1 text-red-500">*</p>
                </div>
                <div className="mt-[10px]">
                  <InsuranceLevel />
                </div>
              </div>
            </div>
          </div>
          <div className="ml-[140px] mt-[40px]">
            <p className="text-[24px]">ລາຍລະອຽດ</p>
            <textarea
              placeholder="ລາຍລະອຽດເພີ່ມເຕີມກ່ຽວກັບປະກັນໄພ, ກ່ຽວກັບລົດ ......."
              className="w-[804px] h-[150px] mt-[20px] pl-[20px] pt-[15px] border-2 border-slale-400 rounded-[8px] focus:outline-none focus:border-green-500 "
            />
          </div>
          <div className="flex justify-center mt-[140px]">
            <NavLink to="/AddProductSecond">
              <button className="w-[180px] h-[60px] rounded-[28px] bg-green-400 text-white text-[20px]">
                ຖັດໄປ
              </button>
            </NavLink>
          </div>
        </div>
      </div>
    </NavBar>
  );
}

export default AddProducts;
