import React from "react";
import NavBar from "../components/NavBar";
import { MdArrowBack } from "react-icons/md"; //icons
import { NavLink } from "react-router-dom";
import { LuMapPin } from "react-icons/lu";
import ImgHeadProduct from ".././assets/images/headproduct.png"; //image
import ImgSideProduct from ".././assets/images/sideproduct.png";
import ImgFootProduct from ".././assets/images/footproduct.png";
import ImgCardProduct from ".././assets/images/cardproduct.png";
import ImgCardProduct1 from ".././assets/images/cardproduct1.png";
import ImgCardProduct2 from ".././assets/images/cardproduct2.png";
import ImgCardUser from ".././assets/images/carduser.png";
import ImgCardUser1 from ".././assets/images/carduser1.png";
import ImgSavelife from ".././assets/images/savelife.jpg";

function ViewProduct() {
  return (
    <NavBar>
      <div className="flex justify-center pt-[40px]">
        <div className="w-[1106px] h-[2880px] bg-white rounded-[6px] font-noto-sans-lao">
          <div className="ml-[40px] mt-[25px] flex space-x-[10px]">
            <NavLink to="/product">
              <MdArrowBack className="w-[42px] h-[42px] text-navbar-text" />
            </NavLink>
            <p className="text-[24px] content-center">ລາຍລະອຽດ</p>
          </div>
          <div className="flex pl-[40px] pt-[40px] space-x-[30px]">
            <div className="bg-file rounded-[6px] cursor-pointer flex justify-center items-center overflow-hidden">
              <img
                src={ImgHeadProduct}
                alt=""
                className="w-[508px] h-[350px] object-cover object-top"
              />
            </div>
            <div>
              <div>
                <img
                  src={ImgSideProduct}
                  alt=""
                  className="w-[454px] h-[160px] object-cover object-top rounded-[6px] cursor-pointer"
                />
              </div>
              <div className="flex mt-[20px]">
                <div>
                  <img
                    src={ImgFootProduct}
                    alt=""
                    className="w-[218px] h-[170px] rounded-[6px] object-cover cursor-pointer"
                  />
                </div>
                <div className="w-[218px] h-[170px] rounded-[6px] ml-[20px] bg-file cursor-pointer"></div>
              </div>
            </div>
          </div>
          <div className="text-[24px] pt-[25px] pb-[15px] mx-[40px] border-b-[2px] flex justify-between">
            <p className="">ລົດຈັກ Honda</p>
            <p className="flex mr-[25px]">
              ລາຄາ :<p className="ml-[20px] text-navbar-text">100,000 </p>
              <p className="ml-[5px]">ກີບ/ມື້</p>
            </p>
          </div>
          <div className="text-[24px] py-[15px] flex justify-end">
            <p className="flex mr-[65px]">
              ຫັກ 10 % :<p className="ml-[20px] text-navbar-text">100,000 </p>
              <p className="ml-[5px]">ກີບ</p>
            </p>
          </div>
          <div className="text-[16px] px-[40px] py-[40px] flex space-x-[30px] text-color-text">
            <div>
              <p className="ml-[15px]">ປະເພດລົດ</p>

              <div className="w-[180px] h-[40px] rounded-[20px] border-[2px] mt-[10px] felx text-center content-center cursor-pointer">
                <p className="text-[16px]">ລົດຈັກ</p>
              </div>
            </div>
            <div>
              <p className="ml-[15px]">ປະເພດເຊື້ອເພີງ</p>
              <div className="w-[180px] h-[40px] rounded-[20px] border-[2px] mt-[10px] felx text-center content-center cursor-pointer">
                <p>ນ້ຳມັນແອັດຊັງ</p>
              </div>
            </div>
            <div>
              <p className="ml-[15px]">ລຸ້ນລົດ</p>
              <div className="w-[180px] h-[40px] rounded-[20px] border-[2px] mt-[10px] felx text-center content-center cursor-pointer">
                <p>Honda Biz</p>
              </div>
            </div>
            <div>
              <p className="ml-[15px]">ລຸ້ນປີລົດ</p>
              <div className="w-[180px] h-[40px] rounded-[20px] border-[2px] mt-[10px] felx text-center content-center cursor-pointer">
                <p>2020</p>
              </div>
            </div>
          </div>
          <div className="mt-[20px]">
            <p className="text-[20px] ml-[40px]">ຂໍ້ມູນພື້ນຖານ</p>
            <div className="text-[16px] text-color-text px-[40px] py-[40px] flex space-x-[30px]">
              <div>
                <p className="ml-[15px]">ລະບົບເກຍ</p>
                <div className="w-[180px] h-[40px] rounded-[20px] border-[2px] mt-[10px] felx text-center content-center cursor-pointer">
                  <p>ເກຍອໍໂຕ້</p>
                </div>
              </div>
              <div>
                <p className="ml-[15px]">ປະຕູ</p>
                <div className="w-[180px] h-[40px] rounded-[20px] border-[2px] mt-[10px] felx text-center content-center cursor-pointer">
                  <p>4 ປະຕູ</p>
                </div>
              </div>
              <div>
                <p className="ml-[15px]">ບ່ອນນັ່ງ</p>
                <div className="w-[180px] h-[40px] rounded-[20px] border-[2px] mt-[10px] felx text-center content-center cursor-pointer">
                  <p>5 ບ່ອນນັ່ງ</p>
                </div>
              </div>
              <div>
                <p className="ml-[15px]">ສີລົດ</p>
                <div className="w-[180px] h-[40px] rounded-[20px] border-[2px] mt-[10px] felx text-center content-center cursor-pointer">
                  <p>ສີນ້ຳເງີນ</p>
                </div>
              </div>
              <div>
                <p className="ml-[15px]">GPS</p>
                <div className="w-[180px] h-[40px] rounded-[20px] border-[2px] mt-[10px] felx text-center content-center cursor-pointer">
                  <p>ມີ</p>
                </div>
              </div>
            </div>
            <div className="py-[25px]">
              <p className="text-[20px] ml-[40px]">ເອກະສານລົດ</p>
              <div className="w-[1022px] h-[190px] border-[2px] rounded-[6px] ml-[40px] my-[10px] flex items-center space-x-[30px]">
                <img
                  src={ImgCardProduct}
                  alt=""
                  className="w-[166px] h-[122px] rounded-[6px] ml-[30px] object-cover"
                />
                <img
                  src={ImgCardProduct1}
                  alt=""
                  className="w-[166px] h-[122px] rounded-[6px] object-cover"
                />
                <img
                  src={ImgCardProduct2}
                  alt=""
                  className="w-[166px] h-[122px] rounded-[6px] object-cover object-top"
                />
              </div>
            </div>
            <div className="my-[20px]">
              <p className="text-[24px] ml-[40px]">ເຈົ້າຂອງລົດ</p>
            </div>
            <div className="mx-[40px] mt-[50px]">
              <div className="flex space-x-[380px]">
                <p className="flex text-[16px] mx-[20px]">
                  ຊື່ <p className="text-red-600 ml-[5px]">*</p>
                </p>
                <p className="flex text-[16px]">
                  ນາມສະກຸນ <p className="text-red-600 ml-[5px]">*</p>
                </p>
              </div>
              <div className="flex space-x-[100px]">
                <div className="w-[322px] h-[44px] rounded-[20px] border-[2px] my-[10px] flex items-center">
                  <p className="text-color-text ml-[30px]">ນາງ ປານີ</p>
                </div>
                <div className="w-[322px] h-[44px] rounded-[20px] border-[2px] my-[10px] flex items-center">
                  <p className="text-color-text ml-[30px]">ສີສັນແກ້ວ</p>
                </div>
              </div>
              <div className="flex space-x-[360px] mt-[25px]">
                <p className="flex text-[16px] mx-[20px]">
                  ເບີໂທ <p className="text-red-600 ml-[5px]">*</p>
                </p>
                <p className="flex text-[16px]">ບ້ານ</p>
              </div>
              <div className="flex space-x-[100px]">
                <div className="flex">
                  <div className="w-[80px] h-[44px] rounded-tl-[20px] rounded-bl-[20px] border-[2px] my-[10px] flex items-center">
                    <p className="text-color-text ml-[20px]">+ 856</p>
                  </div>
                  <div className="w-[240px] h-[44px] rounded-tr-[20px] rounded-br-[20px] border-[2px] my-[10px] ml-[2px] flex items-center">
                    <p className="text-color-text ml-[20px]">020 44455553</p>
                  </div>
                </div>
                <div className="w-[322px] h-[44px] rounded-[20px] border-[2px] my-[10px] flex items-center">
                  <p className="text-color-text ml-[30px]">ບ້ານ ໂພນເຄັງ</p>
                </div>
              </div>
              <div className="flex space-x-[370px] mt-[25px]">
                <p className="flex text-[16px] mx-[20px]">ເມືອງ</p>
                <p className="flex text-[16px]">ແຂວງ</p>
              </div>
              <div className="flex space-x-[100px]">
                <div className="flex">
                  <div className="w-[322px] h-[44px] rounded-[20px] border-[2px] my-[10px] flex items-center">
                    <p className="text-color-text ml-[20px]">ເມືອງໄຊເສດຖາ</p>
                  </div>
                </div>
                <div className="w-[322px] h-[44px] rounded-[20px] border-[2px] my-[10px] flex items-center">
                  <p className="text-color-text ml-[30px]">ນະຄອນຫລວງວຽງຈັນ</p>
                </div>
              </div>
              <div className="mt-[25px]">
                <p className="flex text-[16px] mx-[20px]">
                  ເລກບັດປະຈຳໂຕ <p className="text-red-600 ml-[5px]">*</p>
                </p>
              </div>
              <div className="flex space-x-[100px]">
                <div className="flex">
                  <div className="w-[322px] h-[44px] rounded-[20px] border-[2px] my-[10px] flex items-center">
                    <p className="text-color-text ml-[20px]">
                      111-11-11111-11111
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-[1022px] h-[190px] border-[2px] rounded-[6px] ml-[40px] mt-[5px] flex items-center space-x-[30px]">
              <img
                src={ImgCardUser}
                alt=""
                className="w-[166px] h-[122px] rounded-[6px] ml-[30px] object-cover"
              />
              <img
                src={ImgCardUser1}
                alt=""
                className="w-[166px] h-[122px] rounded-[6px] object-cover"
              />
            </div>
            <div>
              <div className="flex mx-[45px] mt-[40px] space-x-[20px]">
                <LuMapPin className="w-[46px] h-[46px] text-green-500" />
                <div className="flex items-end">
                  <p className="text-[24px]">ທີ່ຢູ່ລົດປັດປຸບັນ</p>
                </div>
              </div>
              <p className="text-[16px] mx-[114px] mt-[15px] text-slate-600">
                Vientian Capital
              </p>
            </div>
          </div>
          <div className="mx-[40px] mt-[50px]">
            <p className="text-[24px]">ປະກັນໄພ</p>
            <div className="mx-[50px] mt-[30px]">
              <img
                src={ImgSavelife}
                alt=""
                className="w-[80px] h-[80px] object-cover cursor-pointer"
              />
            </div>
            <div className="flex mt-[25px] space-x-[40px]">
              <div className="w-[180px] h-[40px] border-[2px] border-green-400 rounded-[20px] flex justify-center items-center cursor-pointer">
                <p>ທິບພະຍະປະກັນໄພ</p>
              </div>
              <div className="w-[180px] h-[40px] border-[2px] border-green-400 rounded-[20px] flex justify-center items-center cursor-pointer">
                <p>ທິບພະຍະປະກັນໄພ</p>
              </div>
            </div>
          </div>
          <div>
            <p className="text-[20px] mx-[40px] mt-[50px]">ລາຍລະອຽດ</p>
            <div className="w-[1022px] h-[190px] border-[2px] rounded-[6px] ml-[40px] mt-[10px] flex items-center space-x-[30px]"></div>
          </div>
          <div className="flex space-x-[30px] justify-center mt-[100px]">
            <button className="w-[180px] h-[60px] border-[1px] text-red-500 border-red-500 rounded-[28px] hover:bg-slate-50 focus:ring-[1px] focus:ring-red-600">
              <NavLink to="/product">
                <p className="text-[20px]">ຍົກເລີກ</p>
              </NavLink>
            </button>
            <button className="w-[180px] h-[60px] rounded-[28px] bg-navbar-text focus:ring-[1px] focus:ring-green-600 hover:bg-green-500">
              <p className="text-[20px] text-white">ອະນຸມັດ</p>
            </button>
          </div>
        </div>
      </div>
    </NavBar>
  );
}

export default ViewProduct;
