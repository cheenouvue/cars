import NavBar from "../components/NavBar";
import React, { useState } from "react";
import "../style/Home.css";
import { CiSearch } from "react-icons/ci"; //icons
import { FaBars, FaPlus, FaBan } from "react-icons/fa";
import { GoPencil } from "react-icons/go";
import { RiDeleteBin6Line } from "react-icons/ri";
import "@fontsource/noto-sans-lao"; //font
import ImgMotorbike from ".././assets/images/motorbike.png"; ///image
import ImgSuv from ".././assets/images/suv.png";
import { NavLink } from "react-router-dom";

function AdminPage({ isOpen, onClose }) {
  const [selectedValue, setSelectedValue] = useState("");

  const handleSelectChange = (event) => {
    setSelectedValue(event.target.value);
  };

  const options = [
    { value: "all", label: "ລໍຖ້າອະນຸມັດ", icon: <FaBars /> },
    { value: "filtered", label: "ຍົກເລີກ", icon: <FaBars /> },
    { value: "default", label: "ສຳເລັດ", icon: <FaBars /> },
  ];

  //ban popup
  return (
    <NavBar>
      <div className="font-noto-sans-lao ml-[20px] pl-[30px] pb-[10px] mt-[35px] border-b-[2px]">
        <ul className="flex space-x-[100px]">
          <li>
            <NavLink
              to="/product"
              className={({ isActive }) =>
                isActive ? "text-green-500" : "text-black"
              }
            >
              <div>ຜູ້ໃຊ້</div>
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/admin"
              className={({ isActive }) =>
                isActive ? "text-green-500" : "text-black"
              }
            >
              ແອັດມິນ
            </NavLink>
          </li>
        </ul>
      </div>
      <div className="w-[1180px] h-[840px] bg-white rounded-[6px] mt-[10px] ml-[20px]">
        <div className="mx-[30px] pt-[40px] font-noto-sans-lao flex justify-between">
          <div className="relative flex items-center">
            <div>
              <CiSearch className="absolute left-[20px] absolute top-[10px] w-[24px] h-[24px]" />
              <input
                className="w-[380px] h-[44px] pl-[50px] pr-[20px] rounded-[20px] border-[1px] border-green-500 focus:outline-none focus:ring-[2px] focus:ring-green-500"
                type="search"
                placeholder="ຄົ້ນຫາ ຊື່, ນາມສະກຸນ, ເບີໂທ...."
              />
            </div>
            <button
              type="submit"
              className="bg-button-search w-[120px] h-[44px] rounded-[20px] text-white mx-[20px]"
            >
              ຄົ້ນຫາ
            </button>
          </div>
          <div className="font-noto-sans-lao">
            <button
              type="submit"
              className="bg-button-search w-[150px] h-[44px] rounded-[20px] text-white mx-[20px]"
            >
              <NavLink to="/addproducts" className="flex items-center">
                <FaPlus className="ml-[20px]" />
                <p className="ml-[20px]">ເພີ່ມລົດເຊົ່າ</p>
              </NavLink>
            </button>
          </div>
        </div>
        <div className="font-noto-sans-lao mt-[50px]">
          <table className="mx-[20px] w-[1118px]">
            <tr className="h-[40px] bg-table-color text-table-text rounded-[2px] text-[16px]">
              <th className="w-[130px]">ຮູບ</th>
              <th className="">ຍີ້ຫໍ້ລົດ</th>
              <th className="">ປະເພດລົດ</th>
              <th className="">ປະເພດເຊື້ອເພີງ</th>
              <th className="">ຂ້ໍມູນພື້ນຖານ</th>
              <th className="">ເຈົ້າຂອງລົດ</th>
              <th className="">ເບີໂທ</th>
              <th className="">ລາຄາ</th>
              <th className="text-center">ຈັດການ</th>
            </tr>
            <tr className="text-[14px] border-b-[2px]">
              <td className="flex justify-center py-[5px]">
                <img
                  src={ImgMotorbike}
                  alt=""
                  className="w-[110px] h-[70px] rounded-[4px] object-contain"
                />
              </td>
              <td className="text-center">ລົດຈັກ Honda</td>
              <td className="text-center">ລົດຈັກ</td>
              <td className="text-center">ປະເພດນ້ຳມັນ</td>
              <td className="text-center">ເກຍອໍໂຕ້</td>
              <td className="text-center">ນາງ ປານີ</td>
              <td className="text-center">020 44455553</td>
              <td className="text-center">
                <p className="text-navbar-text flex justify-center">
                  100.000 <p className="pl-[4px] text-black">ກີບ/ມື້</p>
                </p>
              </td>
              <td>
                <div className="flex justify-center">
                  <button className="w-[60px] h-[30px] rounded-[20px] bg-button-search flex justify-center items-center">
                    <GoPencil className="w-[24px] h-[24px] text-white" />
                  </button>
                  <button className="w-[60px] h-[30px] rounded-[20px] ml-[8px] bg-red-500 flex justify-center items-center">
                    <RiDeleteBin6Line className="w-[24px] h-[24px] text-white" />
                  </button>
                </div>
              </td>
            </tr>
            <tr className="text-[14px] border-b-[2px]">
              <td className="flex justify-center py-[5px]">
                <img
                  src={ImgSuv}
                  alt=""
                  className="w-[110px] h-[70px] rounded-[4px] object-contain"
                />
              </td>
              <td className="text-center">ລົດ SUV Chevrolet</td>
              <td className="text-center">ລົດຕູ້</td>
              <td className="text-center">ປະເພດນ້ຳມັນ</td>
              <td className="text-center">ປະເພດນ້ຳມັນ</td>
              <td className="text-center">ນາງ ປານີ</td>
              <td className="text-center">020 44455553</td>
              <td className="text-center">
                <p className="text-navbar-text flex justify-center">
                  200.000 <p className="pl-[4px] text-black">ກີບ/ມື້</p>
                </p>
              </td>
              <td>
                <div className="flex justify-center">
                  <button className="w-[60px] h-[30px] rounded-[20px] bg-button-search flex justify-center items-center">
                    <GoPencil className="w-[24px] h-[24px] text-white" />
                  </button>
                  <button className="w-[60px] h-[30px] rounded-[20px] ml-[8px] bg-red-500 flex justify-center items-center">
                    <RiDeleteBin6Line className="w-[24px] h-[24px] text-white" />
                  </button>
                </div>
              </td>
            </tr>
            <tr className="text-[14px] border-b-[2px]">
              <td className="flex justify-center py-[5px]">
                <img
                  src={ImgMotorbike}
                  alt=""
                  className="w-[110px] h-[70px] rounded-[4px] object-contain"
                />
              </td>
              <td className="text-center">ລົດຈັກ Honda</td>
              <td className="text-center">ລົດຈັກ</td>
              <td className="text-center">ປະເພດນ້ຳມັນ</td>
              <td className="text-center">ເກຍອໍໂຕ້</td>
              <td className="text-center">ນາງ ປານີ</td>
              <td className="text-center">020 44455553</td>
              <td className="text-center">
                <p className="text-navbar-text flex justify-center">
                  100.000 <p className="pl-[4px] text-black">ກີບ/ມື້</p>
                </p>
              </td>
              <td>
                <div className="flex justify-center">
                  <button className="w-[60px] h-[30px] rounded-[20px] bg-button-search flex justify-center items-center">
                    <GoPencil className="w-[24px] h-[24px] text-white" />
                  </button>
                  <button className="w-[60px] h-[30px] rounded-[20px] ml-[8px] bg-red-500 flex justify-center items-center">
                    <RiDeleteBin6Line className="w-[24px] h-[24px] text-white" />
                  </button>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </NavBar>
  );
}

export default AdminPage;
