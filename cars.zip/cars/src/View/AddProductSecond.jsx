import React, { useState } from "react";
import NavBar from "../components/NavBar";
import AddDataProduct2 from "../components/charts/AddDataProduct2";
import UploadProduct from "../components/input_files/uploadImageProduct";
import { MdArrowBack } from "react-icons/md"; //icons
import { FaUser } from "react-icons/fa";
import { FaCar } from "react-icons/fa6";
import { NavLink } from "react-router-dom";
import { CiSearch } from "react-icons/ci";
// import Example from "./Example";

function AddProductSecond() {
  const [Car, setCar] = useState(null);
  const [Gass, setGass] = useState(null);

  const ChooseCar = (value) => {
    setCar(value);
  };
  const ChooseGass = (value) => {
    setGass(value);
  };
  return (
    <NavBar>
      <div className="font-noto-sans-lao">
        <div className="flex space-x-[20px] items-center ml-[130px] my-[30px]">
          <NavLink to="/AddProducts">
            <MdArrowBack className="w-[42px] h-[46px] text-green-400" />
          </NavLink>
          <p className="text-[24px]">ເພີ່ມຂໍ້ມູນລົດເຊົ່າ</p>
        </div>
        {/* container */}
        <div className="w-[1008px] h-[2620px] bg-white ml-[80px] rounded-[6px]">
          <div className="flex justify-center items-center py-[30px]">
            <div className="w-[40px] h-[40px] bg-green-400 rounded-[20px] flex justify-center items-center mt-[10px]">
              <FaUser className="w-[16px] h-[16px] text-white" />
            </div>
            <div className="fexl items-center">
              <AddDataProduct2 />
            </div>
            <div className="w-[40px] h-[40px] bg-green-400 rounded-[20px] flex justify-center items-center mt-[10px]">
              <FaCar className="w-[16px] h-[16px] text-white" />
            </div>
          </div>
          {/* container */}
          <div className="flex justify-center">
            <UploadProduct />
          </div>
          <div className="ml-[55px] mt-[40px] flex space-x-[100px]">
            <div>
              <div>
                <label htmlFor="kind of car" className="flex ml-4">
                  <p>ລຸ້ນລົດ</p>
                  <p className="text-red-500 ml-1">*</p>
                </label>
                <input
                  type="text"
                  name=""
                  id="kind of car"
                  placeholder="ກະລຸນາປ້ອນຍີ້ຫໍ້ລົດ"
                  className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="kind of car" className="flex ml-4 mt-6">
                  <p>ປີລົດ</p>
                </label>
                <input
                  type="text"
                  name=""
                  id="kind of car"
                  placeholder="ກະລຸນາປ້ອນຍີ້ຫໍ້ລົດ"
                  className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="kind of car" className="flex ml-4 mt-6">
                  <p>ລາຄາ/ມື້</p>
                </label>
                <input
                  type="text"
                  name=""
                  id="kind of car"
                  placeholder="ກະລຸນາກຳນົດລາຄາ"
                  className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                />
              </div>
            </div>
            <div>
              <div>
                <label htmlFor="kind of car" className="flex ml-4">
                  <p>ຍີ້ຫໍລົດ</p>
                  <p className="text-red-500 ml-1">*</p>
                </label>
                <input
                  type="text"
                  name=""
                  id="kind of car"
                  placeholder="ກະລຸນາປ້ອນຍີ້ຫໍ້ລົດ"
                  className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="kind of car" className="flex ml-4 mt-6">
                  <p>ປ້າຍທະບຽນ</p>
                  <p className="text-red-500 ml-1">*</p>
                </label>
                <input
                  type="text"
                  name=""
                  id="kind of car"
                  placeholder="ກະລຸນາປ້ອນຍີ້ຫໍ້ລົດ"
                  className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text focus:border-green-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
          <div className="ml-[55px] mt-[60px]">
            <p className="text-[20px]">ປະເພດລົດ</p>
            <div className="mt-[30px] space-x-[30px]">
              <button
                onClick={() => ChooseCar(1)}
                className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                  Car === 1 ? "bg-green-300 text-white" : ""
                }`}
              >
                ລົດຈັກ
              </button>
              <button
                onClick={() => ChooseCar(2)}
                className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                  Car === 2 ? "bg-green-300 text-white" : ""
                }`}
              >
                ລົດຕູ້
              </button>
              <button
                onClick={() => ChooseCar(3)}
                className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                  Car === 3 ? "bg-green-300 text-white" : ""
                }`}
              >
                ລົດເກັ໋ງ
              </button>
              <button
                onClick={() => ChooseCar(4)}
                className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                  Car === 4 ? "bg-green-300 text-white" : ""
                }`}
              >
                ລົດຖີບ
              </button>
            </div>
            <div className="mt-[40px] space-x-[30px]">
              <button
                onClick={() => ChooseCar(5)}
                className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                  Car === 5 ? "bg-green-300 text-white" : ""
                }`}
              >
                ລົດບັນທຸກ
              </button>
              <button
                onClick={() => ChooseCar(6)}
                className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                  Car === 6 ? "bg-green-300 text-white" : ""
                }`}
              >
                ລົດຮາເລ້
              </button>
              <button
                onClick={() => ChooseCar(7)}
                className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                  Car === 7 ? "bg-green-300 text-white" : ""
                }`}
              >
                ລົດວິນເທດ
              </button>
            </div>
            <div className="mt-[60px]">
              <p className="text-[20px]">ປະເພດເຊື້ອເພີງ</p>
              <div className="mt-[30px] space-x-[30px]">
                <button
                  onClick={() => ChooseGass(1)}
                  className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                    Gass === 1 ? "bg-green-300 text-white" : ""
                  }`}
                >
                  ແອັດຊັງ
                </button>
                <button
                  onClick={() => ChooseGass(2)}
                  className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                    Gass === 2 ? "bg-green-300 text-white" : ""
                  }`}
                >
                  ກະຊວນ
                </button>
                <button
                  onClick={() => ChooseGass(3)}
                  className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                    Gass === 3 ? "bg-green-300 text-white" : ""
                  }`}
                >
                  ແອັດຊັງພິເສດ
                </button>
                <button
                  onClick={() => ChooseGass(4)}
                  className={`w-[180px] h-[40px] rounded-[20px] border-2 border-slate-300 focus:outline-none focus:border-green-300 ${
                    Gass === 4 ? "bg-green-300 text-white" : ""
                  }`}
                >
                  ໄຟຟ້າ
                </button>
              </div>
            </div>
            <div className="mt-[60px]">
              <p className="text-[20px]">ຂໍ້ມູນພື້ນຖານ</p>
              <div className="mt-[50px] flex space-x-[90px]">
                <div>
                  <div>
                    <p className="ml-[20px]">ລະບົບເກຍ</p>
                    <input
                      type="text"
                      name=""
                      placeholder="ເກຍອໍໂຕ້"
                      className="w-[350px] h-[44px] border-2 rounded-[20px] mt-[10px] pl-[40px] focus:outline-none focus:border-green-300"
                    />
                  </div>
                  <div className="mt-[35px]">
                    <p className="ml-[20px]">ບ່ອນນັ່ງ</p>
                    <input
                      type="text"
                      name=""
                      className="w-[350px] h-[44px] border-2 rounded-[20px] mt-[10px] pl-[40px] focus:outline-none focus:border-green-300"
                    />
                  </div>
                  <div className="mt-[35px]">
                    <p className="ml-[20px]">GPS</p>
                    <input
                      type="text"
                      name=""
                      className="w-[350px] h-[44px] border-2 rounded-[20px] mt-[10px] pl-[40px] focus:outline-none focus:border-green-300"
                    />
                  </div>
                </div>
                <div>
                  <div>
                    <p className="ml-[20px]">ປະຕູ</p>
                    <input
                      type="text"
                      name=""
                      className="w-[350px] h-[44px] border-2 rounded-[20px] mt-[10px] pl-[40px] focus:outline-none focus:border-green-300"
                    />
                  </div>
                  <div className="mt-[35px]">
                    <p className="ml-[20px]">ສີລົດ</p>
                    <input
                      type="text"
                      name=""
                      className="w-[350px] h-[44px] border-2 rounded-[20px] mt-[10px] pl-[40px] focus:outline-none focus:border-green-300"
                    />
                  </div>
                  <div className="mt-[35px]">
                    <p className="ml-[20px]">ຄຸນລັກສະນະພິເສດ</p>
                    <input
                      type="text"
                      name=""
                      className="w-[350px] h-[44px] border-2 rounded-[20px] mt-[10px] pl-[40px] focus:outline-none focus:border-green-300"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-[50px]">
              <p className="text-[20px]">ກຳນົດສະຖານທີ່ຮັບລົດ ແລະ ຄືນລົດ</p>
              <div className="relative flex items-center">
                <div>
                  <CiSearch className="absolute left-[20px] absolute top-[10px] w-[24px] h-[24px]" />
                  <input
                    className="w-[380px] h-[44px] pl-[50px] pr-[20px] rounded-[20px] border-[1px] border-green-500 focus:outline-none focus:ring-[2px] focus:ring-green-500"
                    type="search"
                    placeholder="ຄົ້ນຫາ ຊື່, ນາມສະກຸນ, ເບີໂທ...."
                  />
                </div>
                <button
                  type="submit"
                  className="bg-button-search w-[120px] h-[44px] rounded-[20px] text-white mx-[20px]"
                >
                  ຄົ້ນຫາ
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </NavBar>
  );
}

export default AddProductSecond;
