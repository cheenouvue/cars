import React, { useState } from "react";
import NavBar from "../components/NavBar";
import "../style/Home.css";
import { GoPencil } from "react-icons/go";
import { FaBan } from "react-icons/fa";
import { CiSearch } from "react-icons/ci";
import { FaBars } from "react-icons/fa";
import "@fontsource/noto-sans-lao";
import Select from "../components/Select";
import BanPop from "../components/pop/BanPop";
import { NavLink } from "react-router-dom";

function UserPage({ isOpen, onClose }) {
  const [selectedValue, setSelectedValue] = useState("");
  const [isEditing, setIsEditing] = useState(false);

  const handleSelectChange = (event) => {
    setSelectedValue(event.target.value);
  };

  const options = [
    { value: "all", label: "ສະແດງທັງຫມົດ", icon: <FaBars /> },
    { value: "filtered", label: "ຖືກແບບ", icon: <FaBars /> },
    { value: "default", label: "ປົກກະຕິ", icon: <FaBars /> },
  ];

  //ban popup

  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const openPopup = () => setIsPopupOpen(true);
  const closePopup = () => setIsPopupOpen(false);
  return (
    <NavBar>
      {/* //content */}
      <div className="bg-white w-[1158px] absolute top-[100px] absolute left-[266px] rounded-[6px] pb-[30px]">
        <div className="mx-[30px] mt-[40px] font-noto-sans-lao flex justify-between">
          <div className="relative flex items-center">
            <div>
              <CiSearch className="absolute left-[20px] absolute top-[10px] w-[24px] h-[24px]" />
              <input
                className="w-[380px] h-[44px] pl-[50px] pr-[20px] rounded-[20px] border-[1px] border-green-500 focus:outline-none focus:ring-[2px] focus:ring-green-500"
                type="search"
                placeholder="ຄົ້ນຫາ ຊື່, ນາມສະກຸນ, ເບີໂທ...."
              />
            </div>
            <button
              type="submit"
              className="bg-button-search w-[120px] h-[44px] rounded-[20px] text-white mx-[20px]"
            >
              ຄົ້ນຫາ
            </button>
          </div>
          <div className="font-noto-sans-lao">
            <Select
              options={options}
              value={selectedValue}
              onChange={handleSelectChange}
              placeholder="ສະແດງທັງຫມົດ"
            />
          </div>
        </div>
        <p className="font-noto-sans-lao mx-[30px] my-[30px]">
          ຜູ້ໃຊ້ທັງໝົດ 100 ຄົນ
        </p>
        <div className="font-noto-sans-lao">
          <table className="mx-[20px] w-[1118px]">
            <tr className="h-[40px] bg-table-color text-table-text rounded-[2px] text-[16px]">
              <th className="text-start pl-[20px]">ຊື່</th>
              <th className="text-start">ນາມສະກຸນ</th>
              <th className="text-start">ເບີໂທ</th>
              <th className="text-start">ອິເມວ</th>
              <th className="text-start">ລະຫັດຜ່ານ</th>
              <th className="text-start">ວັນທີສະໝັກ</th>
              <th className="text-start">ສະຖານະ</th>
              <th className="">ຈັດການ</th>
            </tr>
            <tr className="h-[40px] rounded-[2px] text-[14px] border-b-[2px]">
              <td className="pl-[20px] py-[20px]">ນ ລິດດາ</td>
              <td className="text-start">ແກ້ວພະສຸກ</td>
              <td className="text-start">020 44455553</td>
              <td className="text-start">Lida@gmail.com</td>
              <td className="text-start">1234</td>
              <td className="text-start">20-02-2024</td>
              <td className="text-start">ປົກກະຕິກ</td>
              <td className="flex justify-center pt-[16px]">
                <button className="w-[50px] h-[28px] border-[1px] border-green-500 rounded-[14px]" onClick={() => setIsEditing(true)}>
                  <NavLink to="/user/edituser">
                    <GoPencil className="w-[24px] h-[24px] text-green-500 ml-[13px]" />
                  </NavLink>
                </button>
                <button
                  className="w-[50px] h-[28px] border-[1px] border-red-500 rounded-[14px] ml-[8px]"
                  onClick={openPopup}
                >
                  <FaBan className="w-[24px] h-[24px] text-red-500 ml-[13px] content-center" />
                </button>
              </td>
            </tr>
            <tr className="h-[40px] rounded-[2px] text-[14px] border-b-[2px]">
              <td className="pl-[20px] py-[20px]">ນ ລິດດາ</td>
              <td className="">ແກ້ວພະສຸກ</td>
              <td className="">020 44455553</td>
              <td className="">Lida@gmail.com</td>
              <td className="">1234</td>
              <td className="">20-02-2024</td>
              <td className="">ປົກກະຕິກ</td>
              <td className="flex justify-center pt-[16px]">
                <button className="w-[50px] h-[28px] border-[1px] border-green-500 rounded-[14px]">
                  <NavLink to="/user/edituser">
                    <GoPencil className="w-[24px] h-[24px] text-green-500 ml-[13px]" />
                  </NavLink>
                </button>
                <button
                  className="w-[50px] h-[28px] border-[1px] border-red-500 rounded-[14px] ml-[8px]"
                  onClick={openPopup}
                >
                  <FaBan className="w-[24px] h-[24px] text-red-500 ml-[13px] content-center" />
                </button>
                <BanPop isOpen={isPopupOpen} onClose={closePopup} />
              </td>
            </tr>
            <tr className="h-[40px] rounded-[2px] text-[14px] border-b-[2px]">
              <td className="pl-[20px] py-[20px]">ນ ລິດດາ</td>
              <td className="">ແກ້ວພະສຸກ</td>
              <td className="">020 44455553</td>
              <td className="">Lida@gmail.com</td>
              <td className="">1234</td>
              <td className="">20-02-2024</td>
              <td className="">ປົກກະຕິກ</td>
              <td className="flex justify-center pt-[16px]">
                <button className="w-[50px] h-[28px] border-[1px] border-green-500 rounded-[14px]">
                  <NavLink to="/user/edituser">
                    <GoPencil className="w-[24px] h-[24px] text-green-500 ml-[13px]" />
                  </NavLink>
                </button>
                <button
                  className="w-[50px] h-[28px] border-[1px] border-red-500 rounded-[14px] ml-[8px]"
                  onClick={openPopup}
                >
                  <FaBan className="w-[24px] h-[24px] text-red-500 ml-[13px] content-center" />
                </button>
                <BanPop isOpen={isPopupOpen} onClose={closePopup} />
              </td>
            </tr>
            <tr className="h-[40px] rounded-[2px] text-[14px] border-b-[2px]">
              <td className="pl-[20px] py-[20px]">ນ ລິດດາ</td>
              <td className="">ແກ້ວພະສຸກ</td>
              <td className="">020 44455553</td>
              <td className="">Lida@gmail.com</td>
              <td className="">1234</td>
              <td className="">20-02-2024</td>
              <td className="">ປົກກະຕິກ</td>
              <td className="flex justify-center pt-[16px]">
                <button className="w-[50px] h-[28px] border-[1px] border-green-500 rounded-[14px]">
                  <NavLink to="/user/edituser">
                    <GoPencil className="w-[24px] h-[24px] text-green-500 ml-[13px]" />
                  </NavLink>
                </button>
                <button
                  className="w-[50px] h-[28px] border-[1px] border-red-500 rounded-[14px] ml-[8px]"
                  onClick={openPopup}
                >
                  <FaBan className="w-[24px] h-[24px] text-red-500 ml-[13px] content-center" />
                </button>
                <BanPop isOpen={isPopupOpen} onClose={closePopup} />
              </td>
            </tr>
            <tr className="h-[40px] rounded-[2px] text-[14px] border-b-[2px]">
              <td className="pl-[20px] py-[20px]">ນ ລິດດາ</td>
              <td className="">ແກ້ວພະສຸກ</td>
              <td className="">020 44455553</td>
              <td className="">Lida@gmail.com</td>
              <td className="">1234</td>
              <td className="">20-02-2024</td>
              <td className="">ປົກກະຕິກ</td>
              <td className="flex justify-center pt-[16px]">
                <button className="w-[50px] h-[28px] border-[1px] border-green-500 rounded-[14px]">
                  <NavLink to="/user/edituser">
                    <GoPencil className="w-[24px] h-[24px] text-green-500 ml-[13px]" />
                  </NavLink>
                </button>
                <button
                  className="w-[50px] h-[28px] border-[1px] border-red-500 rounded-[14px] ml-[8px]"
                  onClick={openPopup}
                >
                  <FaBan className="w-[24px] h-[24px] text-red-500 ml-[13px] content-center" />
                </button>
                <BanPop isOpen={isPopupOpen} onClose={closePopup} />
              </td>
            </tr>
            <tr className="h-[40px] rounded-[2px] text-[14px] border-b-[2px]">
              <td className="pl-[20px] py-[20px]">ນ ລິດດາ</td>
              <td className="">ແກ້ວພະສຸກ</td>
              <td className="">020 44455553</td>
              <td className="">Lida@gmail.com</td>
              <td className="">1234</td>
              <td className="">20-02-2024</td>
              <td className="">ປົກກະຕິກ</td>
              <td className="flex justify-center pt-[16px]">
                <button className="w-[50px] h-[28px] border-[1px] border-green-500 rounded-[14px]">
                  <NavLink to="/user/edituser">
                    <GoPencil className="w-[24px] h-[24px] text-green-500 ml-[13px]" />
                  </NavLink>
                </button>
                <button
                  className="w-[50px] h-[28px] border-[1px] border-red-500 rounded-[14px] ml-[8px]"
                  onClick={openPopup}
                >
                  <FaBan className="w-[24px] h-[24px] text-red-500 ml-[13px] content-center" />
                </button>
                <BanPop isOpen={isPopupOpen} onClose={closePopup} />
              </td>
            </tr>
          </table>
        </div>
      </div>
    </NavBar>
  );
}

export default UserPage;
