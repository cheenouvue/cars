import React, { useState } from "react";
import NavBar from "../components/NavBar";
import PhoneNumberInput from "../components/PhoneNumberInput";
import CardUser from "../components/input_files/CardUser";
import CardProduct from "../components/input_files/CardProduct";
import ImageUser from ".././assets/images/user.png"; //image
import { NavLink } from "react-router-dom"; //icons
import { MdArrowBack } from "react-icons/md";

function EditUserPage() {
  const [name, setname] = useState("ນາງ ລິນດາ");
  const [lastname, setlastname] = useState("ແກ້ວພະສຸກ");
  const [phone, setphone] = useState("20 44455553");
  const [password, setpassword] = useState(1234);
  const [email, setemail] = useState("Lida@gmail.com")
  const [card, setcard] = useState("111-11-11111-11111")

  //name
  const ValueName = (e) => {
    setname(e.target.value);
  };

  //last name
  const ValueLastName = (e) => {
    setlastname(e.target.value);
  };

  //phone
  const ValiePhone = (e) => {
    setphone(e.target.value);
  };

  //password
  const ValuePassword = (e) => {
    setpassword(e.target.value)
  };

  //email
  const ValueaEmail = (e) => {
    setemail(e.target.value);
  };
  const ValueaCard = (e) => {
    setcard(e.target.value);
  };
  return (
    <NavBar>
      <div className="font-noto-sans-lao">
        <div className="ml-[20px] mt-[25px] flex space-x-[10px]">
          <NavLink to="/user/page">
            <MdArrowBack className="w-[42px] h-[42px] text-navbar-text" />
          </NavLink>
          <p className="text-[20px] content-center">ຂໍ້ມູນຜູ້ໃຊ້</p>
        </div>
        <div className="flex">
          <div className="w-[370px] h-[412px] bg-white ml-[20px] mt-[25px] rounded-[6px]">
            <div className="flex justify-center">
              <div className="flex justify-center content-center w-[236px] h-[236px] border-[2px] rounded-[120px] mt-[50px]">
                <img
                  src={ImageUser}
                  alt=""
                  className="w-[210px] h-[210px] object-cover rounded-[110px] mt-[10px]"
                />
              </div>
            </div>
            <p className="flex justify-center mt-[30px]">ນາງ ລິນດາ ແກ້ວພະສຸກ</p>
          </div>
          <div className="w-[720px] h-[900px] bg-white ml-[20px] rounded-[6px] mt-[25px]">
            <div className="">
              <form action="">
                <table className="w-full h-full ml-[20px]">
                  <div className="mt-[30px]"></div>
                  <tr>
                    <td>
                      <label htmlFor="name" className="ml-[20px]">
                        ຊື່
                      </label>
                    </td>
                    <td>
                      <label htmlFor="lastname" className="ml-[20px]">
                        ນາມສະກຸນ
                      </label>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input
                        type="text"
                        name=""
                        id="name"
                        value={name}
                        onChange={ValueName}
                        className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text"
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        name=""
                        id="lastname"
                        value={lastname}
                        onChange={ValueLastName}
                        className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text"
                      />
                    </td>
                  </tr>
                  <div className="mt-[20px]" />
                  <tr>
                    <td>
                      <label htmlFor="phone" className="ml-[20px]">
                        ເບີໂທ
                      </label>
                    </td>
                    <td>
                      <label htmlFor="password" className="ml-[20px]">
                        ລະຫັດ
                      </label>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="flex items-center">
                        <input
                          type="tel"
                          value="+ 856"
                          className="border-[2px] w-[80px] h-[44px] rounded-tl-[20px] rounded-bl-[20px] pl-[20px] mt-[10px] text-color-text"
                        />
                        <input
                          type="tel"
                          id="phone"
                          value={phone}
                          onChange={ValiePhone}
                          className="border-[2px] w-[240px] h-[44px] ml-[2px] rounded-tr-[20px] rounded-br-[20px] pl-[20px] mt-[10px] text-color-text"
                          maxLength="11"
                        />
                      </div>
                    </td>
                    <td>
                      <input
                        type="number"
                        name=""
                        id="password"
                        value={password}
                        onChange={ValuePassword}
                        className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text pr-[10px]"
                      />
                    </td>
                  </tr>
                  <div className="mt-[20px]" />
                  <tr>
                    <td>
                      <label htmlFor="email" className="ml-[20px]">
                        ອີເມວ
                      </label>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <input
                        type="email"
                        name=""
                        id="email"
                        value={email}
                        onChange={ValueaEmail}
                        className="border-[2px] w-[322px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] text-color-text"
                      />
                    </td>
                  </tr>
                </table>
                <div className="mt-[20px]" />
                <label htmlFor="card" className="ml-[40px]">
                  ເລກບັດປະຈຳໂຕ
                </label>
                <input
                  type="text"
                  name=""
                  id="card"
                  value={card}
                  onChange={ValueaCard}
                  className="border-[2px] w-[684px] h-[44px] rounded-[20px] pl-[30px] mt-[10px] ml-[20px] text-color-text"
                />
                <div className="w-[684px] h-[150px] border-[2px] rounded-[20px] mt-[10px] ml-[20px] content-center">
                  <div className="w-[120px] h-[100px] rounded-[4px] ml-[20px]">
                    <CardUser />
                  </div>
                </div>
                <div className="mt-[25px]" />
                <label htmlFor="" className="ml-[40px]">
                  ເອກະສານລົດ
                </label>
                <div className="w-[684px] h-[150px] border-[2px] rounded-[20px] mt-[10px] ml-[20px] content-center">
                  <div className="flex">
                    <CardProduct />
                  </div>
                  {/* <input
                    type="file"
                    name=""
                    id="name"
                    placeholder=""
                    className="ml-[30px] mt-[45px]"
                  />
                  <input
                    type="file"
                    name=""
                    id="name"
                    placeholder=""
                    className="ml-[0px] mt-[45px]"
                  /> */}
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </NavBar>
  );
}

export default EditUserPage;
