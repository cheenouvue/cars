import React from "react";
import NavBar from "../components/NavBar";
import ImgUser from ".././assets/images/all_user.png"; //Image
import ImgSecond from ".././assets/images/file.png";
import ImgThird from ".././assets/images/car.png";
import Imgfour from ".././assets/images/settin_user.png";
import ImgMotorbike from ".././assets/images/motorbike.png";
import ProductCar from ".././assets/images/product_car.png";
import ImgMotorbike2 from ".././assets/images/motobike2.png";
import "../style/Home.css";
import AllUser from "../components/charts/AllUser"; //Echart
import BookAll from "../components/charts/BookAll";
import KindCar from "../components/charts/KindCar";
import AllUserServer from "../components/charts/AllUserServer";
import ViewPage from "../components/charts/Viewpage";
import Booking from "../components/charts/Booking";
import BookTime from "../components/charts/BookTime";
import "@fontsource/noto-sans-lao";

function Home() {
  return (
    <NavBar>
      {/* //content */}
      <div className="flex">
        <div className="flex bg-white rounded-[5px] ml-[20px] mt-[20px] h-[130px]">
          <div>
            <img
              src={ImgUser}
              alt=""
              className="w-[50px] h-[50px] border rounded-[8px] mt-[20px] ml-[20px]"
            />
            <div className="text-[14px] ml-[15px] mt-[25px] font-noto-sans-lao">
              ຜູ້ໃຊ້ທັງໜົດ
            </div>
          </div>
          <div className="mb-[40px] content-center m-[2rem] mt-[20px]">
            <AllUser />
          </div>
        </div>
        <div className="flex bg-white rounded-[5px] ml-[30px] mt-[20px] h-[130px]">
          <div>
            <img
              src={ImgSecond}
              alt=""
              className="w-[50px] h-[50px] border rounded-[8px] mt-[20px] ml-[20px]"
            />
            <div className="text-[14px] ml-[15px] mt-[25px] font-noto-sans-lao">
              ການຈອງທັງໜົດ
            </div>
          </div>
          <div className="mb-[40px] content-center m-[2rem] mt-[20px]">
            <BookAll />
          </div>
        </div>
        <div className="flex bg-white rounded-[5px] ml-[30px] mt-[20px] h-[130px]">
          <div>
            <img
              src={ImgThird}
              alt=""
              className="w-[50px] h-[50px] border rounded-[8px] mt-[20px] ml-[20px] object-contain"
            />
            <div className="text-[14px] ml-[15px] mt-[25px] font-noto-sans-lao">
              ປະເພດລົດທັງໝົດ
            </div>
          </div>
          <div className="mb-[40px] content-center m-[2rem] mt-[20px]">
            <KindCar />
          </div>
        </div>
        <div className="flex bg-white rounded-[5px] ml-[30px] mt-[20px] h-[130px]">
          <div>
            <img
              src={Imgfour}
              alt=""
              className="w-[50px] h-[50px] border rounded-[8px] mt-[20px] ml-[20px]"
            />
            <div className="text-[14px] ml-[15px] mt-[25px] font-noto-sans-lao">
              ຜູ້ໃຊ້ລະບົບທັງໜົດ
            </div>
          </div>
          <div className="mb-[40px] content-center m-[2rem] mt-[20px]">
            <AllUserServer />
          </div>
        </div>
      </div>
      <div className="flex">
        <div className="bg-white rounded-[6px] ml-[20px] mt-[20px]">
          <div className="flex justify-between p-[30px] pb-0 font-noto-sans-lao">
            <p>ຈໍານວນການເຂົ້າໃຊ້ລະບົບ</p>
            <select
              name=""
              id=""
              className="border-green-500 border-[1px] rounded-[2px] text-[10px] focus:outline-none focus:ring-[2px] focus:ring-green-500"
            >
              <option value="ລາຍວັນ">ລາຍວັນ</option>
              <option value="ລາຍອາທິດ">ລາຍອາທິດ</option>
              <option value="ລາຍເດືອນ">ລາຍເດືອນ</option>
            </select>
          </div>
          <ViewPage />
        </div>
        <div className="bg-white rounded-[6px] ml-[20px] mt-[20px] font-noto-sans-lao">
          <p className="m-[30px] mr-[0px] mb-[0px]">
            ສະຖານະການເຊົ່າ
          </p>
          <div className="mb-[30px]">
            <Booking />
          </div>
        </div>
      </div>
      <div className="bg-white font-noto-sans-lao ml-[20px] mt-[20px] rounded-[6px] pb-[30px]">
        <div className="p-[30px]">
          <p>ລາຍການລ່າສຸດ</p>
        </div>
        <div className="bg-slate-50 rounded-[8px] mx-[28px] flex space-x-12">
          <img
            src={ImgMotorbike}
            alt=""
            className="w-[150px] h-[130px] object-cover px-[15px] py-[15px]"
          />
          <div className="space-y-3 pt-[2rem]">
            <p className="text-[16px]">ລົດຈັກ ລຸ້ນ Vespa</p>
            <p className="text-[14px]">ປະເພດລົດ: ລັດຈັກ</p>
            <p className="text-[16px]">100.000ກີບ/ມື້</p>
          </div>
          <div className="space-y-3 pt-[2rem]">
            <p className="text-[16px]">ເຈົ້າຂອງລົດ</p>
            <p className="text-[14px]">ນາງ ສາຍໃຈ ວົງສອນ</p>
          </div>
          <div className="my-[30px]">
            <BookTime />
          </div>
          <div className="space-y-3 pt-[2rem]">
            <p className="text-[16px]">ຜູ້ເຊົ້າ</p>
            <p className="text-[14px]">Mr Jeson</p>
          </div>
          <div className="text-center space-y-3 pt-[2rem]">
            <p className="text-[16px]">ໄລຍະການເຊົ້າ</p>
            <p className="text-[14px]">3 ມື້</p>
          </div>
          <div className="text-[16px] text-center space-y-3 pt-[2rem]">
            <p>ລວມ</p>
            <p>300.000 ກີບ</p>
          </div>
        </div>
        <div className="bg-slate-50 rounded-[8px] flex space-x-10 m-[28px]">
          <img
            src={ProductCar}
            alt=""
            className="w-[150px] h-[130px] object-cover py-[20px]"
          />
          <div className="space-y-3 pt-[2rem]">
            <p className="text-[16px]">ລົດຈັກ SUV Chevrolet</p>
            <p className="text-[14px]">ປະເພດລົດ: ຕູ້</p>
            <p className="text-[16px]">200.000ກີບ/ມື້</p>
          </div>
          <div className="space-y-3 pt-[2rem]">
            <p className="text-[16px]">ເຈົ້າຂອງລົດ</p>
            <p className="text-[14px]">ນາງ ສາຍໃຈ ວົງສອນ</p>
          </div>
          <div className="my-[30px]">
            <BookTime />
          </div>
          <div className="space-y-3 pt-[2rem]">
            <p className="text-[16px]">ຜູ້ເຊົ້າ</p>
            <p className="text-[14px]">Mr Jeson</p>
          </div>
          <div className="space-y-3 pt-[2rem] text-center">
            <p className="text-[16px]">ໄລຍະການເຊົ້າ</p>
            <p className="text-[14px]">3 ມື້</p>
          </div>
          <div className="text-[16px] space-y-3 pt-[2rem] text-center">
            <p>ລວມ</p>
            <p>300.000 ກີບ</p>
          </div>
        </div>
        <div className="bg-slate-50 rounded-[8px] mx-[28px] flex space-x-12">
          <img
            src={ImgMotorbike2}
            alt=""
            className="w-[130px] h-[160px] p-[15px] object-cover"
          />
          <div className="space-y-3 pt-[2rem]">
            <p className="text-[16px]">ລົດຈັກ ລຸ້ນ Honda</p>
            <p className="text-[14px]">ປະເພດລົດ: ລັດຈັກ</p>
            <p className="text-[16px]">100.000ກີບ/ມື້</p>
          </div>
          <div className="space-y-3 pt-[2rem]">
            <p className="text-[16px]">ເຈົ້າຂອງລົດ</p>
            <p className="text-[14px]">ນາງ ສາຍໃຈ ວົງສອນ</p>
          </div>
          <div className="my-[30px]">
            <BookTime />
          </div>
          <div className="space-y-3 pt-[2rem]">
            <p className="text-[16px]">ຜູ້ເຊົ້າ</p>
            <p className="text-[14px]">Mr Jeson</p>
          </div>
          <div className="space-y-3 pt-[2rem] text-center">
            <p className="text-[16px]">ໄລຍະການເຊົ້າ</p>
            <p className="text-[14px]">3 ມື້</p>
          </div>
          <div className="space-y-3 pt-[2rem] text-center">
            <p>ລວມ</p>
            <p>300.000 ກີບ</p>
          </div>
        </div>
      </div>
    </NavBar>
  );
}

export default Home;
