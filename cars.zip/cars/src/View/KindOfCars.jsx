import NavBar from "../components/NavBar";
import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import AppProduct from "../components/pop/AddProduct";
import { CiSearch } from "react-icons/ci"; //icons
import { FaBars, FaPlus } from "react-icons/fa";
import { GoPencil } from "react-icons/go";
import { RiDeleteBin6Line } from "react-icons/ri";
import ImgMotorbike from ".././assets/images/motorbike.png"; //img
import ImgBigCar from ".././assets/images/product_car.png";
import ImgBigCar2 from ".././assets/images/bigcar.png";
import ImgBicycle from ".././assets/images/bicycle.png";
import ImgNewbigcar from ".././assets/images/newbigcar.png";

function KindOfCars({ isOpen, onClose }) {
  const [selectedValue, setSelectedValue] = useState("");

  const handleSelectChange = (event) => {
    setSelectedValue(event.target.value);
  };

  const options = [
    { value: "all", label: "ລໍຖ້າອະນຸມັດ", icon: <FaBars /> },
    { value: "filtered", label: "ຍົກເລີກ", icon: <FaBars /> },
    { value: "default", label: "ສຳເລັດ", icon: <FaBars /> },
  ];

  //popup

  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const openPopup = () => setIsPopupOpen(true);
  const closePopup = () => setIsPopupOpen(false);

  const data_cars = [
    {
      id: 1,
      percent: "ລົດຈັກ 5",
      picture: ImgMotorbike,
      datecreate: "ສ້າງວັນທີ່ 01-05-2024",
      dateconfig: "ເເກ້ໄຂລ່າສຸດ 01-05-2024",
    },
    {
      id: 2,
      percent: "ລົດທົ່ວໄປ 10",
      picture: ImgBigCar,
      datecreate: "ສ້າງວັນທີ່ 01-05-2024",
      dateconfig: "ເເກ້ໄຂລ່າສຸດ 01-05-2024",
    },
    {
      id: 3,
      percent: "ລົດຫຣູ 15",
      picture: ImgBigCar2,
      datecreate: "ສ້າງວັນທີ່ 01-05-2024",
      dateconfig: "ເເກ້ໄຂລ່າສຸດ 01-05-2024",
    },
    {
      id: 4,
      percent: "ລົດຖີບ 5",
      picture: ImgBicycle,
      datecreate: "ສ້າງວັນທີ່ 01-05-2024",
      dateconfig: "ເເກ້ໄຂລ່າສຸດ 01-05-2024",
    },
    {
      id: 5,
      percent: "ລົດເຫມົາ 20",
      picture: ImgNewbigcar,
      datecreate: "ສ້າງວັນທີ່ 01-05-2024",
      dateconfig: "ເເກ້ໄຂລ່າສຸດ 01-05-2024",
    },
  ];
  return (
    <NavBar>
      <div className="font-noto-sans-lao">
        <div className="font-noto-sans-lao ml-[20px] pl-[30px] pb-[10px] mt-[35px] border-b-[2px]">
          <ul className="flex space-x-[100px]">
            <li>
              <NavLink
                to="/kindofcars"
                className={({ isActive }) =>
                  isActive ? "text-green-500" : "text-black"
                }
              >
                ປະເພດລົດ
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/kindofgass"
                className={({ isActive }) =>
                  isActive ? "text-green-500" : "text-black"
                }
              >
                ປະເພດເຊື້ອເພີງ
              </NavLink>
            </li>
          </ul>
        </div>
        <div className="w-[1180px] h-[840px] bg-white rounded-[6px] mt-[10px] ml-[20px]">
          <div className="mx-[30px] pt-[40px] font-noto-sans-lao flex justify-between">
            <div className="relative flex items-center">
              <div>
                <CiSearch className="absolute left-[20px] absolute top-[10px] w-[24px] h-[24px]" />
                <input
                  className="w-[380px] h-[44px] pl-[50px] pr-[20px] rounded-[20px] border-[1px] border-green-500 focus:outline-none focus:ring-[2px] focus:ring-green-500"
                  type="search"
                  placeholder="ຄົ້ນຫາ ຊື່, ນາມສະກຸນ, ເບີໂທ...."
                />
              </div>
              <button
                type="submit"
                className="bg-button-search w-[120px] h-[44px] rounded-[20px] text-white mx-[20px]"
              >
                ຄົ້ນຫາ
              </button>
            </div>
            <div className="font-noto-sans-lao">
              <button
                type="submit"
                className="bg-button-search w-[166px] h-[44px] rounded-[20px] text-white mx-[20px] flex items-center text-[16px]"
                onClick={openPopup}
              >
                <FaPlus className="ml-[25px]" />
                <p className="ml-[20px]">ເພີ່ມລົດເຊົ່າ</p>
              </button>
              <AppProduct isOpen={isPopupOpen} onClose={closePopup} />
            </div>
          </div>
          <div className="ml-[40px] mt-[50px]">
            <p>ປະເພດລົດທັງຫມຫມົດ 4 ປະເພດ</p>
            <div className="flex mt-[30px] grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-y-3 md:gap-y-5">
              {data_cars.map((list, index) => (
                <div key={index} className="shadow-left hover:scale-[1.02]">
                  <div className="w-[180px] h-[47px] sm:w-[200px] md:w-[280px] lg:w-[336px] bg-kind-product rounded-tl-[6px] rounded-tr-[6px] flex justify-center items-center">
                    <p className="text-[20px]">{list.percent} %</p>
                  </div>
                  <div className="w-[180px] h-[160px] sm:w-[200px] md:w-[280px] lg:w-[336px] flex justify-between bg-kind-product rounded-bl-[6px] rounded-br-[6px] mt-[1px] px-[30px] pl-[20px]">
                    <div className="bg-green-50 w-[100px] h-[100px] mt-[20px] flex items-center justify-center rounded-[50px]">
                      <img
                        src={ImgMotorbike}
                        alt=""
                        className="w-[90px] h-[174px] object-contain"
                      />
                    </div>

                    <div className="mt-[20px] space-y-[40px]">
                      <div className="space-y-[10px] text-slate-500">
                        <p className="flex justify-center">
                          ສ້າງວັນທີ່ <p className="pl-[20px]">01-05-2024</p>
                        </p>
                        <p className="flex justify-center">
                          ແກ້ໄຂລ່າສຸດ 01-05-2024
                        </p>
                      </div>
                      <div className="flex justify-center text-white space-x-[10px]">
                        <button className="w-[60px] h-[26px] bg-button-search rounded-[20px] flex items-center space-x-[8px]">
                          <GoPencil className="w-[16px] h-[16px] ml-[6px]" />
                          <p className="text-[10px]">ແກ້ໄຂ</p>
                        </button>
                        <button className="w-[60px] h-[26px] bg-button-delete rounded-[20px] flex items-center space-x-[8px]">
                          <RiDeleteBin6Line className="w-[16px] h-[16px] ml-[10px]" />
                          <p className="text-[10px]">ລົບ</p>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {/* <div className="shadow-left">
                <div className="w-[336px] h-[47px] bg-kind-product rounded-tl-[6px] rounded-tr-[6px] flex justify-center items-center">
                  <p className="text-[20px]">ລົດຈັກ 10 %</p>
                </div>
                <div className="w-[336px] h-[160px] flex justify-between bg-kind-product rounded-bl-[6px] rounded-br-[6px] mt-[1px] px-[30px] pl-[20px]">
                  <div className="bg-green-50 w-[100px] h-[100px] mt-[20px] flex items-center justify-center rounded-[50px]">
                    <img
                      src={ImgBigCar}
                      alt=""
                      className="w-[100px] h-[184px] object-contain"
                    />
                  </div>

                  <div className="mt-[20px] space-y-[40px]">
                    <div className="space-y-[10px] text-slate-500">
                      <p className="flex justify-center">
                        ສ້າງວັນທີ່ <p className="pl-[20px]">01-05-2024</p>
                      </p>
                      <p className="flex justify-center">
                        ແກ້ໄຂລ່າສຸດ 01-05-2024
                      </p>
                    </div>
                    <div className="flex justify-center text-white space-x-[10px]">
                      <button className="w-[60px] h-[26px] bg-button-search rounded-[20px] flex items-center space-x-[8px]">
                        <GoPencil className="w-[16px] h-[16px] ml-[6px]" />
                        <p className="text-[10px]">ແກ້ໄຂ</p>
                      </button>
                      <button className="w-[60px] h-[26px] bg-button-delete rounded-[20px] flex items-center space-x-[8px]">
                        <RiDeleteBin6Line className="w-[16px] h-[16px] ml-[10px]" />
                        <p className="text-[10px]">ລົບ</p>
                      </button>
                    </div>
                  </div>
                </div>
              </div> */}
              {/* <div className="shadow-left">
                <div className="w-[336px] h-[47px] bg-kind-product rounded-tl-[6px] rounded-tr-[6px] flex justify-center items-center">
                  <p className="text-[20px]">ລົດຈັກ 15 %</p>
                </div>
                <div className="w-[336px] h-[160px] flex justify-between bg-kind-product rounded-bl-[6px] rounded-br-[6px] mt-[1px] px-[30px] pl-[20px]">
                  <div className="bg-green-50 w-[100px] h-[100px] mt-[20px] flex items-center justify-center rounded-[50px]">
                    <img
                      src={ImgBigCar2}
                      alt=""
                      className="w-[120px] h-[204px] object-contain"
                    />
                  </div>

                  <div className="mt-[20px] space-y-[40px]">
                    <div className="space-y-[10px] text-slate-500">
                      <p className="flex justify-center">
                        ສ້າງວັນທີ່ <p className="pl-[20px]">01-05-2024</p>
                      </p>
                      <p className="flex justify-center">
                        ແກ້ໄຂລ່າສຸດ 01-05-2024
                      </p>
                    </div>
                    <div className="flex justify-center text-white space-x-[10px]">
                      <button className="w-[60px] h-[26px] bg-button-search rounded-[20px] flex items-center space-x-[8px]">
                        <GoPencil className="w-[16px] h-[16px] ml-[6px]" />
                        <p className="text-[10px]">ແກ້ໄຂ</p>
                      </button>
                      <button className="w-[60px] h-[26px] bg-button-delete rounded-[20px] flex items-center space-x-[8px]">
                        <RiDeleteBin6Line className="w-[16px] h-[16px] ml-[10px]" />
                        <p className="text-[10px]">ລົບ</p>
                      </button>
                    </div>
                  </div>
                </div>
              </div> */}
            </div>
            {/* <div className="flex space-x-[45px] mt-[30px]">
              <div className="shadow-left">
                <div className="w-[336px] h-[47px] bg-kind-product rounded-tl-[6px] rounded-tr-[6px] flex justify-center items-center">
                  <p className="text-[20px]">ລົດຈັກ 5 %</p>
                </div>
                <div className="w-[336px] h-[160px] flex justify-between bg-kind-product rounded-bl-[6px] rounded-br-[6px] mt-[1px] px-[30px] pl-[20px]">
                  <div className="bg-green-50 w-[100px] h-[100px] mt-[20px] flex items-center justify-center rounded-[50px]">
                    <img
                      src={ImgBicycle}
                      alt=""
                      className="w-[120px] h-[204px] object-contain"
                    />
                  </div>

                  <div className="mt-[20px] space-y-[40px]">
                    <div className="space-y-[10px] text-slate-500">
                      <p className="flex justify-center">
                        ສ້າງວັນທີ່ <p className="pl-[20px]">01-05-2024</p>
                      </p>
                      <p className="flex justify-center">
                        ແກ້ໄຂລ່າສຸດ 01-05-2024
                      </p>
                    </div>
                    <div className="flex justify-center text-white space-x-[10px]">
                      <button className="w-[60px] h-[26px] bg-button-search rounded-[20px] flex items-center space-x-[8px]">
                        <GoPencil className="w-[16px] h-[16px] ml-[6px]" />
                        <p className="text-[10px]">ແກ້ໄຂ</p>
                      </button>
                      <button className="w-[60px] h-[26px] bg-button-delete rounded-[20px] flex items-center space-x-[8px]">
                        <RiDeleteBin6Line className="w-[16px] h-[16px] ml-[10px]" />
                        <p className="text-[10px]">ລົບ</p>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="shadow-left">
                <div className="w-[336px] h-[47px] bg-kind-product rounded-tl-[6px] rounded-tr-[6px] flex justify-center items-center">
                  <p className="text-[20px]">ລົດຈັກ 20 %</p>
                </div>
                <div className="w-[336px] h-[160px] flex justify-between bg-kind-product rounded-bl-[6px] rounded-br-[6px] mt-[1px] px-[30px] pl-[20px]">
                  <div className="bg-green-50 w-[100px] h-[100px] mt-[20px] flex items-center justify-center rounded-[50px]">
                    <img
                      src={ImgNewbigcar}
                      alt=""
                      className="w-[120px] h-[204px] object-contain"
                    />
                  </div>

                  <div className="mt-[20px] space-y-[40px]">
                    <div className="space-y-[10px] text-slate-500">
                      <p className="flex justify-center">
                        ສ້າງວັນທີ່ <p className="pl-[20px]">01-05-2024</p>
                      </p>
                      <p className="flex justify-center">
                        ແກ້ໄຂລ່າສຸດ 01-05-2024
                      </p>
                    </div>
                    <div className="flex justify-center text-white space-x-[10px]">
                      <button className="w-[60px] h-[26px] bg-button-search rounded-[20px] flex items-center space-x-[8px]">
                        <GoPencil className="w-[16px] h-[16px] ml-[6px]" />
                        <p className="text-[10px]">ແກ້ໄຂ</p>
                      </button>
                      <button className="w-[60px] h-[26px] bg-button-delete rounded-[20px] flex items-center space-x-[8px]">
                        <RiDeleteBin6Line className="w-[16px] h-[16px] ml-[10px]" />
                        <p className="text-[10px]">ລົບ</p>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </NavBar>
  );
}

export default KindOfCars;
