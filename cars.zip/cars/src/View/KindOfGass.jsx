import NavBar from "../components/NavBar";
import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import AppProduct from "../components/pop/AddProduct";
import { CiSearch } from "react-icons/ci"; //icons
import { FaBars, FaPlus } from "react-icons/fa";
import { GoPencil } from "react-icons/go";
import { RiDeleteBin6Line } from "react-icons/ri";
import { PiGasCanFill } from "react-icons/pi";
import { AiFillThunderbolt } from "react-icons/ai";
import AddGass from "../components/pop/AddGass";

function KindOfCars({ isOpen, onClose }) {
  const [selectedValue, setSelectedValue] = useState("");

  const handleSelectChange = (event) => {
    setSelectedValue(event.target.value);
  };

  const options = [
    { value: "all", label: "ລໍຖ້າອະນຸມັດ", icon: <FaBars /> },
    { value: "filtered", label: "ຍົກເລີກ", icon: <FaBars /> },
    { value: "default", label: "ສຳເລັດ", icon: <FaBars /> },
  ];

  //popup

  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const openPopup = () => setIsPopupOpen(true);
  const closePopup = () => setIsPopupOpen(false);
  return (
    <NavBar>
      <div className="font-noto-sans-lao">
        <div className="font-noto-sans-lao ml-[20px] pl-[30px] pb-[10px] mt-[35px] border-b-[2px]">
          <ul className="flex space-x-[100px]">
            <li>
              <NavLink
                to="/kindofcars"
                className={({ isActive }) =>
                  isActive ? "text-green-500" : "text-black"
                }
              >
                ປະເພດລົດ
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/kindofgass"
                className={({ isActive }) =>
                  isActive ? "text-green-500" : "text-black"
                }
              >
                ປະເພດເຊື້ອເພີງ
              </NavLink>
            </li>
          </ul>
        </div>
        <div className="w-[1180px] h-[840px] bg-white rounded-[6px] mt-[10px] ml-[20px]">
          <div className="mx-[30px] pt-[40px] font-noto-sans-lao flex justify-between">
            <div className="relative flex items-center">
              <div>
                <CiSearch className="absolute left-[20px] absolute top-[10px] w-[24px] h-[24px]" />
                <input
                  className="w-[380px] h-[44px] pl-[50px] pr-[20px] rounded-[20px] border-[1px] border-green-500 focus:outline-none focus:ring-[2px] focus:ring-green-500"
                  type="search"
                  placeholder="ຄົ້ນຫາ ຊື່, ນາມສະກຸນ, ເບີໂທ...."
                />
              </div>
              <button
                type="submit"
                className="bg-button-search w-[120px] h-[44px] rounded-[20px] text-white mx-[20px]"
              >
                ຄົ້ນຫາ
              </button>
            </div>
            <div className="font-noto-sans-lao">
              <button
                type="submit"
                className="bg-button-search w-[166px] h-[44px] rounded-[20px] text-white mx-[20px] flex items-center text-[14px]"
                onClick={openPopup}
              >
                <FaPlus className="ml-[20px]" />
                <p className="ml-[10px]">ເພີ່ມປະເພດເຊື້ອເພີງ</p>
              </button>
              <AddGass isOpen={isPopupOpen} onClose={closePopup} />
            </div>
          </div>
          <div className="ml-[40px] mt-[50px]">
            <p>ປະເພດລົດທັງຫມຫມົດ 4 ປະເພດ</p>
            <div className="flex space-x-[45px] mt-[30px]">
              <div className="shadow-left">
                <div className="w-[336px] h-[47px] bg-kind-product rounded-tl-[6px] rounded-tr-[6px] flex justify-center items-center">
                  <p className="text-[20px]">ປະເພດນ້ຳມັນແອັດຊັງ</p>
                </div>
                <div className="w-[336px] h-[160px] flex justify-between bg-kind-product rounded-bl-[6px] rounded-br-[6px] mt-[1px] px-[30px] pl-[20px]">
                  <div className="bg-green-50 w-[100px] h-[100px] mt-[20px] flex items-center justify-center rounded-[50px]">
                    <PiGasCanFill className="w-[80px] h-[80px] text-green-400" />
                  </div>

                  <div className="mt-[20px] space-y-[40px]">
                    <div className="space-y-[10px] text-slate-500">
                      <p className="flex justify-center">
                        ສ້າງວັນທີ່ <p className="pl-[20px]">01-05-2024</p>
                      </p>
                      <p className="flex justify-center">
                        ແກ້ໄຂລ່າສຸດ 01-05-2024
                      </p>
                    </div>
                    <div className="flex justify-center text-white space-x-[10px]">
                      <button className="w-[60px] h-[26px] bg-button-search rounded-[20px] flex items-center space-x-[8px]">
                        <GoPencil className="w-[16px] h-[16px] ml-[6px]" />
                        <p className="text-[10px]">ແກ້ໄຂ</p>
                      </button>
                      <button className="w-[60px] h-[26px] bg-button-delete rounded-[20px] flex items-center space-x-[8px]">
                        <RiDeleteBin6Line className="w-[16px] h-[16px] ml-[10px]" />
                        <p className="text-[10px]">ລົບ</p>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="shadow-left">
                <div className="w-[336px] h-[47px] bg-kind-product rounded-tl-[6px] rounded-tr-[6px] flex justify-center items-center">
                  <p className="text-[20px]">ປະເພດນ້ຳມັນກາຊວນ</p>
                </div>
                <div className="w-[336px] h-[160px] flex justify-between bg-kind-product rounded-bl-[6px] rounded-br-[6px] mt-[1px] px-[30px] pl-[20px]">
                  <div className="bg-green-50 w-[100px] h-[100px] mt-[20px] flex items-center justify-center rounded-[50px]">
                    <PiGasCanFill className="w-[80px] h-[80px] text-green-400" />
                  </div>

                  <div className="mt-[20px] space-y-[40px]">
                    <div className="space-y-[10px] text-slate-500">
                      <p className="flex justify-center">
                        ສ້າງວັນທີ່ <p className="pl-[20px]">01-05-2024</p>
                      </p>
                      <p className="flex justify-center">
                        ແກ້ໄຂລ່າສຸດ 01-05-2024
                      </p>
                    </div>
                    <div className="flex justify-center text-white space-x-[10px]">
                      <button className="w-[60px] h-[26px] bg-button-search rounded-[20px] flex items-center space-x-[8px]">
                        <GoPencil className="w-[16px] h-[16px] ml-[6px]" />
                        <p className="text-[10px]">ແກ້ໄຂ</p>
                      </button>
                      <button className="w-[60px] h-[26px] bg-button-delete rounded-[20px] flex items-center space-x-[8px]">
                        <RiDeleteBin6Line className="w-[16px] h-[16px] ml-[10px]" />
                        <p className="text-[10px]">ລົບ</p>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="shadow-left">
                <div className="w-[336px] h-[47px] bg-kind-product rounded-tl-[6px] rounded-tr-[6px] flex justify-center items-center">
                  <p className="text-[20px]">ປະເພດໃຊ້ໄຟຟ້າ</p>
                </div>
                <div className="w-[336px] h-[160px] flex justify-between bg-kind-product rounded-bl-[6px] rounded-br-[6px] mt-[1px] px-[30px] pl-[20px]">
                  <div className="bg-green-50 w-[100px] h-[100px] mt-[20px] flex items-center justify-center rounded-[50px]">
                    <AiFillThunderbolt className="w-[80px] h-[80px] text-yellow-400" />
                  </div>

                  <div className="mt-[20px] space-y-[40px]">
                    <div className="space-y-[10px] text-slate-500">
                      <p className="flex justify-center">
                        ສ້າງວັນທີ່ <p className="pl-[20px]">01-05-2024</p>
                      </p>
                      <p className="flex justify-center">
                        ແກ້ໄຂລ່າສຸດ 01-05-2024
                      </p>
                    </div>
                    <div className="flex justify-center text-white space-x-[10px]">
                      <button className="w-[60px] h-[26px] bg-button-search rounded-[20px] flex items-center space-x-[8px]">
                        <GoPencil className="w-[16px] h-[16px] ml-[6px]" />
                        <p className="text-[10px]">ແກ້ໄຂ</p>
                      </button>
                      <button className="w-[60px] h-[26px] bg-button-delete rounded-[20px] flex items-center space-x-[8px]">
                        <RiDeleteBin6Line className="w-[16px] h-[16px] ml-[10px]" />
                        <p className="text-[10px]">ລົບ</p>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-[30px]">
              <div className="w-[336px] h-[47px] bg-kind-product rounded-tl-[6px] rounded-tr-[6px] flex justify-center items-center shadow-left">
                <p className="text-[20px]">ປະເພດນ້ຳມັນແອັດຊັງພີເສດ</p>
              </div>
              <div className="w-[336px] h-[160px] flex justify-between bg-kind-product rounded-bl-[6px] rounded-br-[6px] mt-[1px] px-[30px] pl-[20px] shadow-left">
                <div className="bg-green-50 w-[100px] h-[100px] mt-[20px] flex items-center justify-center rounded-[50px]">
                  <PiGasCanFill className="w-[80px] h-[80px] text-green-400" />
                </div>

                <div className="mt-[20px] space-y-[40px]">
                  <div className="space-y-[10px] text-slate-500">
                    <p className="flex justify-center">
                      ສ້າງວັນທີ່ <p className="pl-[20px]">01-05-2024</p>
                    </p>
                    <p className="flex justify-center">
                      ແກ້ໄຂລ່າສຸດ 01-05-2024
                    </p>
                  </div>
                  <div className="flex justify-center text-white space-x-[10px]">
                    <button className="w-[60px] h-[26px] bg-button-search rounded-[20px] flex items-center space-x-[8px]">
                      <GoPencil className="w-[16px] h-[16px] ml-[6px]" />
                      <p className="text-[10px]">ແກ້ໄຂ</p>
                    </button>
                    <button className="w-[60px] h-[26px] bg-button-delete rounded-[20px] flex items-center space-x-[8px]">
                      <RiDeleteBin6Line className="w-[16px] h-[16px] ml-[10px]" />
                      <p className="text-[10px]">ລົບ</p>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </NavBar>
  );
}

export default KindOfCars;
