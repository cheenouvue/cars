import React from "react";
import Home from "../View/Home";
import User from "../View/User";
import EditUserPage from "../View/EditUserPage";
import Product from "../View/Product";
import AdminPage from "../View/AdminPage";
import ViewProduct from "../View/ViewProduct";
import KindOfCars from "../View/KindOfCars";
import KindOfGass from "../View/KindOfGass";
import AddProducts from "../View/AddProducts";
import AddProductSecond from "../View/AddProductSecond";
import Ex from "../View/Example";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

function AppRouter() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Home />} />
        <Route path="/user/page" element={<User />} />
        <Route path="/user/edituser" element={<EditUserPage />} />
        <Route path="/product" element={<Product />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/viewproduct" element={<ViewProduct />} />
        <Route path="/kindofcars" element={<KindOfCars />} />
        <Route path="/kindofgass" element={<KindOfGass />} />
        <Route path="/addproducts" element={<AddProducts />} />
        <Route path="/addproductsecond" element={<AddProductSecond />} />
        <Route path="/ex" element={<Ex />} />
      </Routes>
    </Router>
  );
}

export default AppRouter;
